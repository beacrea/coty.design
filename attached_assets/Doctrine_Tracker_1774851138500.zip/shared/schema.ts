import { z } from "zod";

// Status levels for claims — ordered by evidence strength
export const claimStatuses = [
  "Proposed",
  "Active",
  "Emerging",
  "Supported",
  "Strongly supported",
  "Contentious",
  "Refuted (for now)",
  "Retired",
] as const;

export type ClaimStatus = (typeof claimStatuses)[number];

export const evidenceTierSchema = z.enum(["A", "B", "C", "D"]);
export type EvidenceTier = z.infer<typeof evidenceTierSchema>;

export interface EvidenceItem {
  title: string;
  author?: string;
  url?: string;
  tier?: EvidenceTier;
  summary?: string;
  type: "support" | "challenge" | "counter";
}

export interface SkepticEntry {
  objection: string;
  falsificationCriteria: string[];
}

export interface MetricEntry {
  name: string;
  description: string;
}

export interface Claim {
  id: string;
  number: string;
  title: string;
  shortTitle: string;
  statement: string;
  rationale: string;
  status: ClaimStatus;
  lastChanged: string;
  keySignal: string;
  supportingSignals: string[];
  challenges: string[];
  q1Observations: string[];
  evaluationCriteria: string[];
  evidence: EvidenceItem[];
  skepticism?: SkepticEntry;
  metrics: MetricEntry[];
  splitNote?: string;
}

export interface DoctrineMetadata {
  title: string;
  author: string;
  organization: string;
  creationDate: string;
  revisionDate: string;
  version: string;
  reviewCadence: string;
}

export interface Doctrine {
  metadata: DoctrineMetadata;
  coreThesis: string;
  executiveSummary: {
    coreThesis: string;
    whyMatters: string;
    takeaway: string;
  };
  claims: Claim[];
  definitions: { term: string; definition: string }[];
  scope: { inScope: string[]; outOfScope: string[] };
  closingPrinciple: string;
}
