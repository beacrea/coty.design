import type { ClaimStatus } from "@shared/schema";

const statusConfig: Record<
  string,
  { bg: string; text: string; dot: string; label?: string }
> = {
  "Proposed": {
    bg: "bg-amber-100 dark:bg-amber-900/30",
    text: "text-amber-700 dark:text-amber-400",
    dot: "bg-amber-500",
  },
  "Active": {
    bg: "bg-blue-100 dark:bg-blue-900/30",
    text: "text-blue-700 dark:text-blue-400",
    dot: "bg-blue-500",
  },
  "Emerging": {
    bg: "bg-cyan-100 dark:bg-cyan-900/30",
    text: "text-cyan-700 dark:text-cyan-400",
    dot: "bg-cyan-500",
  },
  "Supported": {
    bg: "bg-emerald-100 dark:bg-emerald-900/30",
    text: "text-emerald-700 dark:text-emerald-400",
    dot: "bg-emerald-500",
  },
  "Strongly supported": {
    bg: "bg-green-100 dark:bg-green-900/30",
    text: "text-green-700 dark:text-green-400",
    dot: "bg-green-500",
    label: "Strongly Supported",
  },
  "Contentious": {
    bg: "bg-orange-100 dark:bg-orange-900/30",
    text: "text-orange-700 dark:text-orange-400",
    dot: "bg-orange-500",
  },
  "Refuted (for now)": {
    bg: "bg-red-100 dark:bg-red-900/30",
    text: "text-red-700 dark:text-red-400",
    dot: "bg-red-500",
    label: "Refuted",
  },
  "Retired": {
    bg: "bg-gray-100 dark:bg-gray-800/30",
    text: "text-gray-600 dark:text-gray-400",
    dot: "bg-gray-400",
  },
};

export function StatusBadge({ status, size = "sm" }: { status: string; size?: "sm" | "md" }) {
  const config = statusConfig[status] || statusConfig["Active"];
  const label = config.label || status;

  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full font-medium ${config.bg} ${config.text} ${
        size === "sm" ? "px-2 py-0.5 text-[11px]" : "px-2.5 py-1 text-xs"
      }`}
      data-testid={`status-badge-${status}`}
    >
      <span className={`w-1.5 h-1.5 rounded-full ${config.dot}`} />
      {label}
    </span>
  );
}

export function statusColor(status: string): string {
  switch (status) {
    case "Proposed": return "hsl(38 70% 50%)";
    case "Active": return "hsl(215 60% 52%)";
    case "Emerging": return "hsl(195 70% 42%)";
    case "Supported": return "hsl(158 55% 40%)";
    case "Strongly supported": return "hsl(142 60% 38%)";
    case "Contentious": return "hsl(30 85% 52%)";
    case "Refuted (for now)": return "hsl(0 65% 50%)";
    default: return "hsl(220 8% 55%)";
  }
}
