/**
 * Visual confidence meter — inspired by Ground News bias bar but for evidence strength.
 * Shows 5 dots representing the confidence progression from Proposed → Strongly Supported.
 */

const levels = [
  { key: "Proposed", position: 0 },
  { key: "Active", position: 1 },
  { key: "Emerging", position: 2 },
  { key: "Supported", position: 3 },
  { key: "Strongly supported", position: 4 },
];

function getLevel(status: string): number {
  const found = levels.find((l) => l.key === status);
  if (found) return found.position;
  if (status === "Contentious") return 2;
  if (status === "Refuted (for now)") return 0;
  return 1;
}

const dotColors = [
  "bg-amber-500",    // Proposed
  "bg-blue-500",     // Active
  "bg-cyan-500",     // Emerging
  "bg-emerald-500",  // Supported
  "bg-green-500",    // Strongly Supported
];

export function ConfidenceMeter({
  status,
  size = "sm",
}: {
  status: string;
  size?: "sm" | "md";
}) {
  const currentLevel = getLevel(status);
  const dotSize = size === "sm" ? "w-1.5 h-1.5" : "w-2 h-2";
  const gap = size === "sm" ? "gap-1" : "gap-1.5";

  return (
    <div className={`flex items-center ${gap}`} role="meter" aria-label={`Confidence: ${status}`}>
      {levels.map((level, i) => (
        <span
          key={level.key}
          className={`${dotSize} rounded-full transition-colors ${
            i <= currentLevel
              ? dotColors[i]
              : "bg-muted-foreground/20"
          }`}
        />
      ))}
    </div>
  );
}

/**
 * Larger confidence bar for claim detail pages.
 * Shows a horizontal bar with labeled segments.
 */
export function ConfidenceBar({ status }: { status: string }) {
  const currentLevel = getLevel(status);

  const segmentColors = [
    { label: "Proposed", hsl: "38 70% 50%", dark: "38 65% 58%" },
    { label: "Active", hsl: "215 60% 52%", dark: "215 55% 60%" },
    { label: "Emerging", hsl: "195 70% 42%", dark: "195 60% 52%" },
    { label: "Supported", hsl: "158 55% 40%", dark: "158 50% 50%" },
    { label: "Strongly\nSupported", hsl: "142 60% 38%", dark: "142 55% 48%" },
  ];

  return (
    <div className="space-y-2">
      <div className="flex h-2.5 rounded-full overflow-hidden bg-muted gap-0.5">
        {segmentColors.map((seg, i) => (
          <div
            key={seg.label}
            className={`flex-1 rounded-full transition-all ${
              i <= currentLevel ? "opacity-100" : "opacity-20"
            }`}
            style={{
              backgroundColor: `hsl(${seg.hsl})`,
            }}
          />
        ))}
      </div>
      <div className="flex justify-between">
        {segmentColors.map((seg, i) => (
          <span
            key={seg.label}
            className={`text-[10px] text-center leading-tight ${
              i <= currentLevel
                ? "text-muted-foreground font-medium"
                : "text-muted-foreground/40"
            } ${i === currentLevel ? "font-semibold" : ""}`}
            style={{ width: `${100 / segmentColors.length}%` }}
          >
            {seg.label.replace("\n", " ")}
          </span>
        ))}
      </div>
    </div>
  );
}
