import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { getQueryFn } from "@/lib/queryClient";
import { Sun, Moon, ChevronRight, BookOpen, Layers, AlertTriangle, Shield, Users, GitBranch, Bot } from "lucide-react";
import { useTheme } from "@/components/theme-provider";
import { StatusBadge, statusColor } from "@/components/status-badge";
import { ConfidenceMeter } from "@/components/confidence-meter";
import type { Doctrine } from "@shared/schema";

const claimIcons: Record<string, any> = {
  "claim-1": Layers,
  "claim-2": BookOpen,
  "claim-3": AlertTriangle,
  "claim-4": Shield,
  "claim-5a": Users,
  "claim-5b": GitBranch,
  "claim-6": Bot,
};

export default function Dashboard() {
  const { theme, toggleTheme } = useTheme();
  const { data: doctrine, isLoading } = useQuery<Doctrine>({
    queryKey: ["/api/doctrine"],
    queryFn: getQueryFn({ on401: "throw" }),
  });

  if (isLoading || !doctrine) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
          <p className="text-sm text-muted-foreground">Parsing doctrine...</p>
        </div>
      </div>
    );
  }

  const statusOrder: Record<string, number> = {
    "Strongly supported": 6,
    "Supported": 5,
    "Emerging": 4,
    "Active": 3,
    "Proposed": 2,
    "Contentious": 1,
    "Refuted (for now)": 0,
    "Retired": -1,
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/60 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <DoctrineLogoSVG />
            <div>
              <h1 className="text-base font-semibold tracking-tight leading-tight">Doctrine Tracker</h1>
              <p className="text-xs text-muted-foreground">
                {doctrine.metadata.version} · Updated {doctrine.metadata.revisionDate}
              </p>
            </div>
          </div>
          <button
            onClick={toggleTheme}
            className="p-2 rounded-md hover:bg-accent transition-colors"
            aria-label={`Switch to ${theme === "dark" ? "light" : "dark"} mode`}
            data-testid="theme-toggle"
          >
            {theme === "dark" ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
        {/* Thesis Banner */}
        <section className="mb-10">
          <div className="bg-card border border-border rounded-lg p-6 sm:p-8">
            <p className="text-xs uppercase tracking-widest text-muted-foreground font-medium mb-3">Core Thesis</p>
            <p className="text-lg font-medium leading-relaxed text-foreground max-w-3xl">
              {doctrine.executiveSummary.coreThesis}
            </p>
            <p className="text-sm text-muted-foreground mt-3 max-w-2xl leading-relaxed">
              {doctrine.executiveSummary.whyMatters}
            </p>
          </div>
        </section>

        {/* Status Distribution Bar — Ground News-style */}
        <section className="mb-8">
          <h2 className="text-xs uppercase tracking-widest text-muted-foreground font-medium mb-3">
            Evidence Confidence Distribution
          </h2>
          <EvidenceDistributionBar claims={doctrine.claims} />
        </section>

        {/* Claims Grid */}
        <section>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xs uppercase tracking-widest text-muted-foreground font-medium">
              {doctrine.claims.length} Foundational Claims
            </h2>
          </div>

          <div className="grid gap-3">
            {doctrine.claims.map((claim) => {
              const Icon = claimIcons[claim.id] || Layers;
              const supportCount = claim.evidence.filter((e) => e.type === "support").length;
              const counterCount = claim.evidence.filter((e) => e.type === "counter").length;

              return (
                <Link
                  key={claim.id}
                  href={`/claim/${claim.id}`}
                  className="block"
                >
                  <div
                    className="group bg-card border border-border rounded-lg p-4 sm:p-5 hover:border-primary/30 hover:shadow-md transition-all cursor-pointer"
                    data-testid={`claim-card-${claim.id}`}
                  >
                    <div className="flex items-start gap-4">
                      {/* Icon + Number */}
                      <div
                        className="hidden sm:flex w-10 h-10 rounded-lg items-center justify-center shrink-0"
                        style={{
                          backgroundColor: `hsl(${statusColorRaw(claim.status)} / 0.1)`,
                          color: `hsl(${statusColorRaw(claim.status)})`,
                        }}
                      >
                        <Icon className="w-5 h-5" />
                      </div>

                      {/* Content */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-3 mb-2">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-xs font-mono text-muted-foreground">{claim.number}</span>
                            <StatusBadge status={claim.status} />
                          </div>
                          <ChevronRight className="w-4 h-4 text-muted-foreground shrink-0 mt-0.5 opacity-0 group-hover:opacity-100 transition-opacity" />
                        </div>

                        <h3 className="font-semibold text-sm leading-snug mb-1.5 text-foreground">
                          {claim.title}
                        </h3>

                        <p className="text-sm text-muted-foreground leading-relaxed line-clamp-2 mb-3">
                          {claim.statement}
                        </p>

                        {/* Bottom row: key signal + evidence count */}
                        <div className="flex items-center gap-4 flex-wrap">
                          <div className="flex items-center gap-1.5">
                            <ConfidenceMeter status={claim.status} size="sm" />
                          </div>
                          <span className="text-xs text-muted-foreground">
                            {claim.keySignal}
                          </span>
                          {(supportCount > 0 || counterCount > 0) && (
                            <div className="flex items-center gap-2 ml-auto">
                              {supportCount > 0 && (
                                <span className="text-xs text-muted-foreground flex items-center gap-1">
                                  <span className="w-2 h-2 rounded-full bg-emerald-500/70" />
                                  {supportCount} supporting
                                </span>
                              )}
                              {counterCount > 0 && (
                                <span className="text-xs text-muted-foreground flex items-center gap-1">
                                  <span className="w-2 h-2 rounded-full bg-amber-500/70" />
                                  {counterCount} counter
                                </span>
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </Link>
              );
            })}
          </div>
        </section>

        {/* Definitions */}
        {doctrine.definitions.length > 0 && (
          <section className="mt-10">
            <h2 className="text-xs uppercase tracking-widest text-muted-foreground font-medium mb-3">
              Working Definitions
            </h2>
            <div className="bg-card border border-border rounded-lg divide-y divide-border">
              {doctrine.definitions.map((def) => (
                <div key={def.term} className="p-4">
                  <dt className="font-semibold text-sm mb-1">{def.term}</dt>
                  <dd className="text-sm text-muted-foreground leading-relaxed">{def.definition}</dd>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Footer */}
        <footer className="mt-12 pt-6 border-t border-border text-center">
          <p className="text-xs text-muted-foreground italic max-w-lg mx-auto leading-relaxed">
            "{doctrine.closingPrinciple}"
          </p>
          <p className="text-xs text-muted-foreground mt-3">
            {doctrine.metadata.author} · {doctrine.metadata.organization} · {doctrine.metadata.reviewCadence} review
          </p>
        </footer>
      </main>
    </div>
  );
}

function statusColorRaw(status: string): string {
  switch (status) {
    case "Proposed": return "var(--status-proposed)";
    case "Active": return "var(--status-active)";
    case "Emerging": return "var(--status-emerging)";
    case "Supported": return "var(--status-supported)";
    case "Strongly supported": return "var(--status-strongly-supported)";
    case "Contentious": return "var(--status-contentious)";
    case "Refuted (for now)": return "var(--status-refuted)";
    default: return "var(--muted-foreground)";
  }
}

function EvidenceDistributionBar({ claims }: { claims: Doctrine["claims"] }) {
  const statusGroups = [
    { key: "Strongly supported", label: "Strongly Supported", claims: [] as typeof claims },
    { key: "Supported", label: "Supported", claims: [] as typeof claims },
    { key: "Emerging", label: "Emerging", claims: [] as typeof claims },
    { key: "Active", label: "Active", claims: [] as typeof claims },
    { key: "Proposed", label: "Proposed", claims: [] as typeof claims },
  ];

  for (const claim of claims) {
    const group = statusGroups.find((g) => g.key === claim.status);
    if (group) group.claims.push(claim);
    else {
      // fallback to active
      statusGroups[3].claims.push(claim);
    }
  }

  const total = claims.length;

  return (
    <div className="space-y-2">
      {/* The bar */}
      <div className="flex h-3 rounded-full overflow-hidden bg-muted gap-[2px]">
        {statusGroups.map((group) => {
          if (group.claims.length === 0) return null;
          const pct = (group.claims.length / total) * 100;
          return (
            <div
              key={group.key}
              className="h-full transition-all first:rounded-l-full last:rounded-r-full"
              style={{
                width: `${pct}%`,
                backgroundColor: `hsl(${statusColorRawCSS(group.key)})`,
              }}
              title={`${group.label}: ${group.claims.length} claim${group.claims.length > 1 ? "s" : ""}`}
            />
          );
        })}
      </div>

      {/* Legend */}
      <div className="flex items-center gap-4 flex-wrap">
        {statusGroups.map((group) => {
          if (group.claims.length === 0) return null;
          return (
            <div key={group.key} className="flex items-center gap-1.5">
              <span
                className="w-2.5 h-2.5 rounded-full shrink-0"
                style={{ backgroundColor: `hsl(${statusColorRawCSS(group.key)})` }}
              />
              <span className="text-xs text-muted-foreground">
                {group.label} ({group.claims.length})
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function statusColorRawCSS(status: string): string {
  switch (status) {
    case "Proposed": return "38 70% 50%";
    case "Active": return "220 55% 48%";
    case "Emerging": return "180 65% 40%";
    case "Supported": return "158 55% 40%";
    case "Strongly supported": return "142 60% 38%";
    case "Contentious": return "30 85% 52%";
    case "Refuted (for now)": return "0 65% 50%";
    default: return "220 8% 55%";
  }
}

function DoctrineLogoSVG() {
  return (
    <svg
      width="28"
      height="28"
      viewBox="0 0 32 32"
      fill="none"
      aria-label="Doctrine Tracker"
      className="shrink-0"
    >
      {/* Three layered squares representing abstraction levels */}
      <rect x="4" y="4" width="14" height="14" rx="2" stroke="currentColor" strokeWidth="2" />
      <rect x="10" y="10" width="14" height="14" rx="2" stroke="currentColor" strokeWidth="2" opacity="0.6" />
      <rect x="16" y="16" width="12" height="12" rx="2" fill="currentColor" opacity="0.15" stroke="currentColor" strokeWidth="2" />
      {/* Dot representing a claim */}
      <circle cx="11" cy="11" r="2" fill="hsl(215 60% 52%)" />
    </svg>
  );
}
