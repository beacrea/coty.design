import { useQuery } from "@tanstack/react-query";
import { useRoute, Link } from "wouter";
import { getQueryFn } from "@/lib/queryClient";
import {
  ArrowLeft,
  Sun,
  Moon,
  ChevronDown,
  ChevronRight,
  ExternalLink,
  ShieldCheck,
  ShieldAlert,
  Scale,
  BarChart3,
  AlertCircle,
  Quote,
} from "lucide-react";
import { useTheme } from "@/components/theme-provider";
import { StatusBadge } from "@/components/status-badge";
import { ConfidenceBar } from "@/components/confidence-meter";
import { useState } from "react";
import type { Claim, EvidenceItem } from "@shared/schema";

export default function ClaimDetail() {
  const { theme, toggleTheme } = useTheme();
  const [, params] = useRoute("/claim/:id");
  const claimId = params?.id;

  const { data: claim, isLoading } = useQuery<Claim>({
    queryKey: ["/api/claims", claimId],
    queryFn: getQueryFn({ on401: "throw" }),
    enabled: !!claimId,
  });

  if (isLoading || !claim) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
          <p className="text-sm text-muted-foreground">Loading claim...</p>
        </div>
      </div>
    );
  }

  const supportEvidence = claim.evidence.filter((e) => e.type === "support");
  const counterEvidence = claim.evidence.filter((e) => e.type === "counter");
  const totalEvidence = claim.evidence.length;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/60 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors" data-testid="back-link">
            <ArrowLeft className="w-4 h-4" />
            All Claims
          </Link>
          <button
            onClick={toggleTheme}
            className="p-2 rounded-md hover:bg-accent transition-colors"
            aria-label={`Switch to ${theme === "dark" ? "light" : "dark"} mode`}
            data-testid="theme-toggle"
          >
            {theme === "dark" ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 sm:px-6 py-8">
        {/* ═══ LEVEL 2: Claim Overview ═══ */}
        <section className="mb-8">
          <div className="flex items-center gap-2 mb-3 flex-wrap">
            <span className="text-xs font-mono text-muted-foreground">{claim.number}</span>
            <StatusBadge status={claim.status} size="md" />
            {claim.lastChanged && (
              <span className="text-xs text-muted-foreground">· since {claim.lastChanged}</span>
            )}
          </div>

          <h1 className="text-xl font-semibold tracking-tight mb-3 leading-snug">
            {claim.title}
          </h1>

          {claim.splitNote && (
            <p className="text-xs text-muted-foreground italic mb-4 bg-accent/50 rounded px-3 py-2">
              {claim.splitNote}
            </p>
          )}

          {/* Statement block */}
          <div className="bg-card border border-border rounded-lg p-5 mb-6">
            <p className="text-sm leading-relaxed text-foreground">{claim.statement}</p>
            <p className="text-sm text-muted-foreground mt-3 leading-relaxed">{claim.rationale}</p>
          </div>

          {/* Confidence Bar */}
          <div className="mb-6">
            <p className="text-xs uppercase tracking-widest text-muted-foreground font-medium mb-2">
              Confidence Level
            </p>
            <ConfidenceBar status={claim.status} />
          </div>
        </section>

        {/* ═══ LEVEL 2: Evidence Balance ═══ */}
        {totalEvidence > 0 && (
          <section className="mb-8">
            <h2 className="text-xs uppercase tracking-widest text-muted-foreground font-medium mb-3 flex items-center gap-2">
              <Scale className="w-3.5 h-3.5" />
              Evidence Balance
            </h2>

            {/* Balance Bar — Ground News style */}
            <EvidenceBalanceBar support={supportEvidence.length} counter={counterEvidence.length} />

            {/* Evidence lists — Level 3 drilldown */}
            <div className="grid sm:grid-cols-2 gap-4 mt-5">
              <EvidenceColumn
                title="Supporting"
                icon={<ShieldCheck className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />}
                items={supportEvidence}
                accentColor="emerald"
              />
              <EvidenceColumn
                title="Challenging"
                icon={<ShieldAlert className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />}
                items={counterEvidence}
                accentColor="amber"
              />
            </div>
          </section>
        )}

        {/* ═══ LEVEL 2: Q1 2026 Observations ═══ */}
        {claim.q1Observations.length > 0 && (
          <section className="mb-8">
            <h2 className="text-xs uppercase tracking-widest text-muted-foreground font-medium mb-3">
              Q1 2026 Observations
            </h2>
            <div className="bg-card border border-border rounded-lg divide-y divide-border">
              {claim.q1Observations.map((obs, i) => (
                <div key={i} className="p-4 text-sm text-muted-foreground leading-relaxed">
                  {obs}
                </div>
              ))}
            </div>
          </section>
        )}

        {/* ═══ LEVEL 2: Signals ═══ */}
        <div className="grid sm:grid-cols-2 gap-6 mb-8">
          {claim.supportingSignals.length > 0 && (
            <section>
              <h2 className="text-xs uppercase tracking-widest text-muted-foreground font-medium mb-3 flex items-center gap-2">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                Supporting Signals
              </h2>
              <ul className="space-y-2">
                {claim.supportingSignals.map((s, i) => (
                  <li key={i} className="text-sm text-muted-foreground leading-relaxed flex gap-2">
                    <span className="w-1 h-1 rounded-full bg-emerald-500 shrink-0 mt-2" />
                    {s}
                  </li>
                ))}
              </ul>
            </section>
          )}

          {claim.challenges.length > 0 && (
            <section>
              <h2 className="text-xs uppercase tracking-widest text-muted-foreground font-medium mb-3 flex items-center gap-2">
                <ShieldAlert className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                Challenges / Counter-signals
              </h2>
              <ul className="space-y-2">
                {claim.challenges.map((c, i) => (
                  <li key={i} className="text-sm text-muted-foreground leading-relaxed flex gap-2">
                    <span className="w-1 h-1 rounded-full bg-amber-500 shrink-0 mt-2" />
                    {c}
                  </li>
                ))}
              </ul>
            </section>
          )}
        </div>

        {/* ═══ LEVEL 2: Skepticism ═══ */}
        {claim.skepticism && claim.skepticism.objection && (
          <section className="mb-8">
            <h2 className="text-xs uppercase tracking-widest text-muted-foreground font-medium mb-3 flex items-center gap-2">
              <AlertCircle className="w-3.5 h-3.5" />
              Skeptic's Challenge
            </h2>
            <div className="bg-card border border-border rounded-lg p-5">
              <div className="flex gap-3 mb-4">
                <Quote className="w-4 h-4 text-muted-foreground shrink-0 mt-0.5" />
                <p className="text-sm leading-relaxed italic text-foreground">
                  {claim.skepticism.objection}
                </p>
              </div>
              {claim.skepticism.falsificationCriteria.length > 0 && (
                <div>
                  <p className="text-xs uppercase tracking-widest text-muted-foreground font-medium mb-2">
                    What would falsify this claim
                  </p>
                  <ul className="space-y-1.5">
                    {claim.skepticism.falsificationCriteria.map((f, i) => (
                      <li key={i} className="text-sm text-muted-foreground leading-relaxed flex gap-2">
                        <span className="w-1 h-1 rounded-full bg-red-400 shrink-0 mt-2" />
                        {f}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </section>
        )}

        {/* ═══ LEVEL 2: Metrics ═══ */}
        {claim.metrics.length > 0 && (
          <section className="mb-8">
            <h2 className="text-xs uppercase tracking-widest text-muted-foreground font-medium mb-3 flex items-center gap-2">
              <BarChart3 className="w-3.5 h-3.5" />
              Measurable Signals
            </h2>
            <div className="bg-card border border-border rounded-lg divide-y divide-border">
              {claim.metrics.map((m, i) => (
                <div key={i} className="p-4">
                  <p className="text-sm font-medium mb-0.5">{m.name}</p>
                  <p className="text-sm text-muted-foreground">{m.description}</p>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Evaluation Criteria */}
        {claim.evaluationCriteria.length > 0 && (
          <section className="mb-8">
            <h2 className="text-xs uppercase tracking-widest text-muted-foreground font-medium mb-3">
              Evaluation Criteria
            </h2>
            <ul className="space-y-1.5">
              {claim.evaluationCriteria.map((e, i) => (
                <li key={i} className="text-sm text-muted-foreground leading-relaxed flex gap-2">
                  <span className="w-1 h-1 rounded-full bg-primary shrink-0 mt-2" />
                  {e}
                </li>
              ))}
            </ul>
          </section>
        )}
      </main>
    </div>
  );
}

/* ═══ Evidence Balance Bar (Ground News-inspired) ═══ */
function EvidenceBalanceBar({ support, counter }: { support: number; counter: number }) {
  const total = support + counter;
  if (total === 0) return null;

  const supportPct = Math.round((support / total) * 100);
  const counterPct = 100 - supportPct;

  return (
    <div>
      <div className="flex h-3 rounded-full overflow-hidden bg-muted">
        <div
          className="h-full bg-emerald-500 dark:bg-emerald-400 transition-all rounded-l-full"
          style={{ width: `${supportPct}%` }}
        />
        <div
          className="h-full bg-amber-500 dark:bg-amber-400 transition-all rounded-r-full"
          style={{ width: `${counterPct}%` }}
        />
      </div>
      <div className="flex justify-between mt-1.5">
        <span className="text-xs text-emerald-600 dark:text-emerald-400 font-medium">
          {support} supporting ({supportPct}%)
        </span>
        <span className="text-xs text-amber-600 dark:text-amber-400 font-medium">
          {counter} counter ({counterPct}%)
        </span>
      </div>
    </div>
  );
}

/* ═══ Evidence Column (Level 3 drill-down) ═══ */
function EvidenceColumn({
  title,
  icon,
  items,
  accentColor,
}: {
  title: string;
  icon: React.ReactNode;
  items: EvidenceItem[];
  accentColor: "emerald" | "amber";
}) {
  if (items.length === 0) {
    return (
      <div className="bg-card border border-border rounded-lg p-4">
        <div className="flex items-center gap-2 mb-3">
          {icon}
          <h3 className="text-xs uppercase tracking-widest text-muted-foreground font-medium">{title}</h3>
        </div>
        <p className="text-xs text-muted-foreground italic">No evidence catalogued yet</p>
      </div>
    );
  }

  return (
    <div className="bg-card border border-border rounded-lg p-4">
      <div className="flex items-center gap-2 mb-3">
        {icon}
        <h3 className="text-xs uppercase tracking-widest text-muted-foreground font-medium">
          {title} ({items.length})
        </h3>
      </div>
      <div className="space-y-2">
        {items.map((item, i) => (
          <EvidenceCard key={i} item={item} accentColor={accentColor} />
        ))}
      </div>
    </div>
  );
}

/* ═══ Single Evidence Card (Level 3 deep detail) ═══ */
function EvidenceCard({ item, accentColor }: { item: EvidenceItem; accentColor: string }) {
  const [expanded, setExpanded] = useState(false);

  const tierColors: Record<string, string> = {
    A: "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-400",
    B: "bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-400",
    C: "bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-400",
    D: "bg-gray-100 text-gray-600 dark:bg-gray-800/40 dark:text-gray-400",
  };

  return (
    <div
      className="border border-border rounded-md hover:border-primary/20 transition-colors cursor-pointer"
      onClick={() => setExpanded(!expanded)}
      data-testid={`evidence-card-${item.title?.slice(0, 20)}`}
    >
      <div className="p-3">
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1.5 mb-1 flex-wrap">
              {item.tier && (
                <span className={`text-[10px] font-semibold px-1.5 py-0.5 rounded ${tierColors[item.tier] || tierColors.D}`}>
                  Tier {item.tier}
                </span>
              )}
              {item.author && (
                <span className="text-[11px] text-muted-foreground">{item.author}</span>
              )}
            </div>
            <p className="text-sm font-medium leading-snug">{item.title}</p>
          </div>
          {(item.summary || item.url) && (
            <ChevronDown
              className={`w-3.5 h-3.5 text-muted-foreground shrink-0 mt-1 transition-transform ${
                expanded ? "rotate-180" : ""
              }`}
            />
          )}
        </div>
      </div>

      {/* Expanded detail — Level 3 */}
      {expanded && (item.summary || item.url) && (
        <div className="px-3 pb-3 border-t border-border pt-2">
          {item.summary && (
            <p className="text-xs text-muted-foreground leading-relaxed mb-2">{item.summary}</p>
          )}
          {item.url && (
            <a
              href={item.url}
              target="_blank"
              rel="noopener noreferrer"
              className="text-xs text-primary hover:underline inline-flex items-center gap-1"
              onClick={(e) => e.stopPropagation()}
            >
              View source <ExternalLink className="w-3 h-3" />
            </a>
          )}
        </div>
      )}
    </div>
  );
}
