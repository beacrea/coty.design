/**
 * Normalizes doctrine-1.md into a consistent, machine-parseable format.
 * 
 * Changes:
 * 1. Merges "Evidence Registry" and "Sources & References" into a single
 *    per-claim evidence block inside each claim section
 * 2. Standardizes all evidence entries to a consistent format:
 *    - **[Title](url)** — Author — Tier X
 *      Summary text here
 * 3. Uses consistent section markers: <!-- evidence -->, <!-- skepticism -->, <!-- metrics -->
 * 4. Normalizes "Why included" → "Summary" 
 * 5. Removes duplicate source entries
 */

import fs from "fs";

const raw = fs.readFileSync("doctrine-1.md", "utf-8");

// ─── Parse evidence from "Sources and references" section ───
interface EvidenceEntry {
  title: string;
  author: string;
  url: string;
  tier: string;
  summary: string;
  type: "support" | "counter";
}

function parseSourcesEvidence(): Map<string, EvidenceEntry[]> {
  const result = new Map<string, EvidenceEntry[]>();

  const sourcesMatch = raw.match(
    /## Sources and references.*?\n([\s\S]*?)(?=<\/details>)/
  );
  if (!sourcesMatch) return result;

  // Also get the evidence registry
  const registryMatch = raw.match(
    /## Evidence registry \(annotated\)\n([\s\S]*?)(?=\n## Sources and references|<\/details>)/
  );

  const combined = (registryMatch?.[1] || "") + "\n" + sourcesMatch[1];

  // Split by claim headers
  const sections = combined.split(/(?=### (?:Evidence for )?Claim \d)/);

  for (const section of sections) {
    const headerMatch = section.match(/### (?:Evidence for )?Claim (\d+\w?)\b/i);
    if (!headerMatch) continue;

    const claimKey = headerMatch[1].toLowerCase();
    const items: EvidenceEntry[] = [];
    let currentType: "support" | "counter" = "support";

    const lines = section.split("\n");
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];

      // Type detection
      if (/\*\*Support/i.test(line) || /\*\*Tier A/i.test(line) || /\*\*Q1 2026/i.test(line) || /\*\*framing/i.test(line)) {
        currentType = "support";
        continue;
      }
      if (/\*\*Challenge/i.test(line) || /\*\*Best counter/i.test(line) || /\*\*Critiques/i.test(line) || /\*\*cautions/i.test(line) || /\*\*Operational cautionary/i.test(line)) {
        currentType = "counter";
        continue;
      }

      // Parse italic entries: - *Title* — Author — Date — URL
      const italicMatch = line.match(/^- \*(.+?)\*\s*(?:—\s*(.+?))?$/);
      if (italicMatch) {
        const titlePart = italicMatch[1].trim();
        const rest = italicMatch[2] || "";
        
        // Extract URL from rest
        const urlMatch = rest.match(/(https?:\/\/[^\s]+)/);
        const url = urlMatch?.[1] || "";
        const authorParts = rest.replace(/(https?:\/\/[^\s]+)/, "").replace(/\s*—\s*$/, "").replace(/\s*—\s*/g, " · ").trim();

        // Look ahead for summary/why-included
        let summary = "";
        for (let j = i + 1; j <= i + 3 && j < lines.length; j++) {
          const next = lines[j]?.trim();
          if (next?.startsWith("<br>**Summary:**")) {
            summary = next.replace(/<br>\*\*Summary:\*\*\s*/, "");
          } else if (next?.startsWith("<br>**Why included:**")) {
            summary = next.replace(/<br>\*\*Why included:\*\*\s*/, "");
          }
        }

        // Check for URL on next line if not found
        if (!url && i + 1 < lines.length) {
          const nextLine = lines[i + 1]?.trim();
          if (nextLine?.match(/^https?:\/\//)) {
            // URL on separate line
          }
        }

        // Infer tier from nearby context
        let tier = "";
        const nearContext = lines.slice(Math.max(0, i - 5), i + 1).join(" ");
        const tierMatch = nearContext.match(/Tier ([ABCD])/i);
        if (tierMatch) tier = tierMatch[1].toUpperCase();
        // Also check entry summary for tier
        const summaryTier = summary.match(/Tier ([ABCD])/i);
        if (summaryTier && !tier) tier = summaryTier[1].toUpperCase();

        items.push({
          title: titlePart,
          author: authorParts,
          url,
          tier,
          summary,
          type: currentType,
        });
        continue;
      }

      // Parse non-italic counter entries: "- METR RCT above: ..."
      const plainMatch = line.match(/^- (.{15,})$/);
      if (plainMatch) {
        const text = plainMatch[1].trim();
        // Skip section headers and tier definitions
        if (text.startsWith("**") && text.endsWith("**")) continue;
        if (/^\*\*Tier [ABCD]:\*\*/.test(text)) continue;
        // Skip interpretation lines
        if (text.startsWith("General critique")) continue;
        
        let summary = "";
        for (let j = i + 1; j <= i + 3 && j < lines.length; j++) {
          const next = lines[j]?.trim();
          if (next?.startsWith("<br>**Why included:**")) {
            summary = next.replace(/<br>\*\*Why included:\*\*\s*/, "");
            break;
          }
          if (next?.startsWith("<br>**Summary:**")) {
            summary = next.replace(/<br>\*\*Summary:\*\*\s*/, "");
            break;
          }
        }

        items.push({
          title: text.replace(/\*\*/g, "").replace(/\*/g, ""),
          author: "",
          url: "",
          tier: "",
          summary,
          type: currentType,
        });
      }
    }

    // Merge with existing, deduplicate by title
    const existing = result.get(claimKey) || [];
    const seen = new Set(existing.map(e => e.title.toLowerCase()));
    for (const item of items) {
      if (!seen.has(item.title.toLowerCase())) {
        existing.push(item);
        seen.add(item.title.toLowerCase());
      }
    }
    result.set(claimKey, existing);
  }

  return result;
}

// ─── Parse skepticism ───
interface SkepticEntry {
  objection: string;
  falsification: string[];
}

function parseSkepticism(): Map<string, SkepticEntry> {
  const result = new Map<string, SkepticEntry>();
  const skepticMatch = raw.match(
    /## Skeptic's appendix.*?\n([\s\S]*?)(?=<\/details>)/
  );
  if (!skepticMatch) return result;

  const sections = skepticMatch[1].split(/(?=### Skepticism toward Claim \d)/);
  for (const section of sections) {
    const headerMatch = section.match(/### Skepticism toward Claim (\d+\w?)\b/i);
    if (!headerMatch) continue;

    const claimKey = headerMatch[1].toLowerCase();
    const objectionMatch = section.match(/\*\*Objection:\*\*\s*(.+)/);
    const falsifyMatch = section.match(
      /\*\*What would falsify the claim:\*\*\s*\n((?:- .+\n?)+)/
    );
    const falsification = falsifyMatch
      ? falsifyMatch[1].split("\n").filter(l => l.trim().startsWith("- ")).map(l => l.trim().replace(/^- /, ""))
      : [];

    result.set(claimKey, {
      objection: objectionMatch?.[1]?.trim() || "",
      falsification,
    });
  }

  return result;
}

// ─── Parse metrics ───
interface MetricEntry {
  name: string;
  description: string;
}

function parseMetrics(): Map<string, MetricEntry[]> {
  const result = new Map<string, MetricEntry[]>();
  const metricsMatch = raw.match(
    /## Metrics and instrumentation.*?\n([\s\S]*?)(?=<\/details>)/
  );
  if (!metricsMatch) return result;

  const sections = metricsMatch[1].split(/(?=### Claim \d)/);
  for (const section of sections) {
    const headerMatch = section.match(/### Claim (\d+\w?)\b/i);
    if (!headerMatch) continue;

    const claimKey = headerMatch[1].toLowerCase();
    const bullets = section.split("\n").filter(l => l.trim().startsWith("- "));
    const metrics: MetricEntry[] = bullets.map(line => {
      const text = line.trim().replace(/^- /, "");
      const parts = text.match(/\*\*(.+?)\*\*:?\s*(.*)/);
      return {
        name: parts?.[1] || text,
        description: parts?.[2] || "",
      };
    });

    result.set(claimKey, metrics);
  }

  return result;
}

// ─── Build normalized markdown ───
const evidenceMap = parseSourcesEvidence();
const skepticismMap = parseSkepticism();
const metricsMap = parseMetrics();

// Log stats
for (const [key, items] of evidenceMap) {
  const sup = items.filter(e => e.type === "support").length;
  const ctr = items.filter(e => e.type === "counter").length;
  console.log(`Claim ${key}: ${items.length} evidence (${sup}S/${ctr}C)`);
}

// ─── Extract the core sections we'll keep ───

// Get everything up to "## Foundational claims" + claims
const preClaimsMatch = raw.match(/([\s\S]*?)(?=## Foundational claims)/);
const preClaims = preClaimsMatch?.[1] || "";

// Get foundational claims section
const foundationalMatch = raw.match(
  /## Foundational claims\n([\s\S]*?)(?=\n<!-- pagebreak -->|\n## Relationship to Arbuckle)/
);
const foundationalSection = foundationalMatch?.[1] || "";

// Get Relationship to Arbuckle
const arbuckleMatch = raw.match(
  /## Relationship to Arbuckle\n([\s\S]*?)(?=\n---\n)/
);
const arbuckleSection = arbuckleMatch ? `## Relationship to Arbuckle\n${arbuckleMatch[1]}` : "";

// Get telecom translation
const telecomMatch = raw.match(
  /<details>\n<summary><strong>📡 Telecom Translation Layer<\/strong>[^<]*<\/summary>\n([\s\S]*?)<\/details>/
);

// Get status rules
const statusRulesMatch = raw.match(
  /<details>\n<summary><strong>⚖️ Status Rules<\/strong>[^<]*<\/summary>\n([\s\S]*?)<\/details>/
);

// Get review cadence (not in details)
const reviewMatch = raw.match(
  /## Review cadence\n([\s\S]*?)(?=\n<details>)/
);

// Get changelog
const changelogMatch = raw.match(
  /<details>\n<summary><strong>📜 Changelog<\/strong><\/summary>\n([\s\S]*?)<\/details>/
);

// Get closing principle
const closingMatch = raw.match(
  /## Closing principle\n([\s\S]*?)$/
);

// ─── Rebuild each claim section with embedded evidence ───
function formatEvidence(entries: EvidenceEntry[]): string {
  if (entries.length === 0) return "";
  
  const support = entries.filter(e => e.type === "support");
  const counter = entries.filter(e => e.type === "counter");
  
  let out = "\n<!-- evidence -->\n\n";
  
  if (support.length > 0) {
    out += "**Supporting evidence**\n\n";
    for (const e of support) {
      const tierTag = e.tier ? ` · Tier ${e.tier}` : "";
      const authorTag = e.author ? ` — ${e.author}` : "";
      if (e.url) {
        out += `- **[${e.title}](${e.url})**${authorTag}${tierTag}\n`;
      } else {
        out += `- **${e.title}**${authorTag}${tierTag}\n`;
      }
      if (e.summary) {
        out += `  ${e.summary}\n`;
      }
      out += "\n";
    }
  }
  
  if (counter.length > 0) {
    out += "**Counter-evidence**\n\n";
    for (const e of counter) {
      const tierTag = e.tier ? ` · Tier ${e.tier}` : "";
      const authorTag = e.author ? ` — ${e.author}` : "";
      if (e.url) {
        out += `- **[${e.title}](${e.url})**${authorTag}${tierTag}\n`;
      } else {
        out += `- **${e.title}**${authorTag}${tierTag}\n`;
      }
      if (e.summary) {
        out += `  ${e.summary}\n`;
      }
      out += "\n";
    }
  }
  
  return out;
}

function formatSkepticism(entry: SkepticEntry | undefined): string {
  if (!entry || !entry.objection) return "";
  
  let out = "<!-- skepticism -->\n\n";
  out += `**Skeptic's objection:** ${entry.objection}\n\n`;
  if (entry.falsification.length > 0) {
    out += "**What would falsify this claim:**\n";
    for (const f of entry.falsification) {
      out += `- ${f}\n`;
    }
  }
  out += "\n";
  return out;
}

function formatMetrics(entries: MetricEntry[] | undefined): string {
  if (!entries || entries.length === 0) return "";
  
  let out = "<!-- metrics -->\n\n";
  out += "**Measurable signals**\n";
  for (const m of entries) {
    out += `- **${m.name}:** ${m.description}\n`;
  }
  out += "\n";
  return out;
}

// Split claims and rebuild
const claimSections = foundationalSection.split(/(?=### Claim \d)/);
let normalizedClaims = "## Foundational claims\n\n";
normalizedClaims += "Each claim is intentionally crisp. Each includes rationale, current support, known challenges, and evaluation criteria.\n\n---\n\n";

for (const section of claimSections) {
  if (!section.match(/^### Claim \d/)) continue;
  
  const numMatch = section.match(/### Claim (\d+\w?)/);
  const claimNum = numMatch?.[1]?.toLowerCase() || "";
  
  // Keep the original claim section text
  normalizedClaims += section.trim() + "\n";
  
  // Append evidence, skepticism, metrics
  const evidence = evidenceMap.get(claimNum) || [];
  const skepticism = skepticismMap.get(claimNum);
  const metrics = metricsMap.get(claimNum);
  
  normalizedClaims += formatEvidence(evidence);
  normalizedClaims += formatSkepticism(skepticism);
  normalizedClaims += formatMetrics(metrics);
  normalizedClaims += "---\n\n";
}

// ─── Assemble final document ───
let output = preClaims;
output += normalizedClaims;
output += "\n<!-- pagebreak -->\n\n";
output += arbuckleSection + "\n\n---\n\n";

// Keep status rules, telecom, changelog as collapsed sections
if (statusRulesMatch) {
  output += `<details>\n<summary><strong>⚖️ Status Rules</strong> — How claims change state</summary>\n${statusRulesMatch[1]}</details>\n\n---\n\n`;
}

if (telecomMatch) {
  output += `<details>\n<summary><strong>📡 Telecom Translation Layer</strong> — Domain-specific mapping</summary>\n${telecomMatch[1]}</details>\n\n---\n\n`;
}

// Review cadence
if (reviewMatch) {
  output += `## Review cadence\n${reviewMatch[1]}`;
}

if (changelogMatch) {
  output += `<details>\n<summary><strong>📜 Changelog</strong></summary>\n${changelogMatch[1]}</details>\n\n---\n\n`;
}

if (closingMatch) {
  output += `## Closing principle\n${closingMatch[1]}`;
}

fs.writeFileSync("doctrine-normalized.md", output.trim() + "\n");
console.log("\nWrote doctrine-normalized.md");
console.log(`Original: ${raw.length} chars`);
console.log(`Normalized: ${output.length} chars`);
