<details>
<summary><strong>📋 Document Metadata</strong> (click to expand)</summary>

```yaml
document_title: "Doctrine: Ontological Orchestration in AI-Assisted Development"
document_type: "Living doctrine / claim ledger"

primary_author:
  name: "Coty Beasley"
  role_at_time_of_writing: "Product design, engineering, and innovation leadership (founder/operator context)"
  affiliation_at_time_of_writing:
    organization: "Underline Infrastructure"
    organization_description: "Telecommunications, software-driven platform"

initial_creation_date: "2025-12"
current_revision_date: "2026-03-30"

intended_lifespan: "Ongoing"
review_cadence: "Quarterly"

intended_audience:
  - "Product management"
  - "Product design"
  - "Software engineering"
  - "Technical leadership"

industry_context: "Telecommunications with heavy software-defined operations and marketplace dynamics"
technological_context: "Rapidly evolving AI-assisted development tooling (LLMs, agentic systems, harness-based workflows)"
time_horizon_addressed: "Near- to mid-term (0–5 years)"
status_at_archive_time: "Active doctrine under evaluation"

canonical_artifacts_referenced:
  - name: "Arbuckle"
    description: "Planning and harness framework; private reference implementation"
    access: "Private"
  - name: "Internal product, billing, provisioning, and support systems"
    access: "Internal"

versioning:
  scheme: "Semantic Versioning"
  format: "vMAJOR.MINOR.PATCH"
  rules:
    MAJOR: "Thesis or core claims change"
    MINOR: "Evidence updates; claim status changes"
    PATCH: "Clarifications; formatting; links"

review_history:
  - date: "2026-03-30"
    type: "Quarterly"
    version_after: "v1.0.0"
    notes: "First quarterly review. Claim 5 split (5a/5b). Claim 6 promoted."

archival_intent: >
  This section exists to preserve historical context. Future readers should interpret claims
  relative to the state of AI capabilities, organizational scale, and industry conditions at the
  time of each revision.
```

</details>

<!-- 
  ═══ STRUCTURED DATA (JSON-LD) ═══
  Machine-readable representation of this doctrine.
  The UI reads from this block; the markdown below is the human-readable narrative.
  When updating claims, evidence, or statuses, update BOTH this block and the markdown.
-->
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "DigitalDocument",
  "title": "Doctrine: Ontological Orchestration in AI-Assisted Development",
  "author": "Coty Beasley",
  "organization": "Underline Infrastructure",
  "creationDate": "2025-12",
  "revisionDate": "2026-03-30",
  "version": "v1.0.0",
  "reviewCadence": "Quarterly",
  "executiveSummary": {
    "coreThesis": "Technology roles are shifting from doing to defining\u2014execution is abundant; alignment, framing, and validation are the new bottlenecks.",
    "whyMatters": "AI amplifies both clarity and confusion. Organizations that formalize intent, constraints, and shared meaning will outpace those that don't.",
    "takeaway": "The six claims below are falsifiable bets about how work is changing. They're evidence-backed, regularly reviewed, and expected to evolve."
  },
  "coreThesis": "Technology roles are shifting from discrete execution to ontological orchestration: the definition, constraint, and sequencing of meaning in systems where execution is increasingly abundant.",
  "scope": {
    "inScope": [
      "Knowledge work and software\u2011driven organizations",
      "Product, design, engineering, and leadership roles",
      "AI systems as *execution amplifiers*, not moral agents",
      "Near\u2011 to mid\u2011term horizons (0\u20135 years)"
    ],
    "outOfScope": [
      "AGI timelines",
      "Societal collapse / utopia narratives",
      "Moral philosophy of artificial minds",
      "Vendor\u2011specific forecasts"
    ]
  },
  "definitions": [
    {
      "term": "Ontological orchestration",
      "definition": "The act of defining *what exists*, *what matters*, *how components relate*, and *what constitutes correctness* in a system\u2014before and during execution."
    },
    {
      "term": "Harness",
      "definition": "A structured package of intent, constraints, artifacts, and validation mechanisms that bounds and guides execution (human or agentic)."
    },
    {
      "term": "Intent hypothesis",
      "definition": "A falsifiable statement describing a believed problem, its context, constraints, and success criteria."
    },
    {
      "term": "Situated authorship",
      "definition": "Authorship determined by surface\u2011area expertise and problem context rather than formal role."
    }
  ],
  "claims": [
    {
      "id": "claim-1",
      "number": "Claim 1",
      "title": "Execution is no longer the dominant constraint",
      "statement": "For most software\u2011driven organizations, the cost of producing artifacts (code, designs, drafts) is falling faster than the cost of deciding *what should exist* and *how it should behave*.",
      "rationale": "AI systems dramatically reduce realization latency, enabling rapid generation and iteration. This amplifies the cost of poor framing and weak constraints.",
      "status": "Active",
      "lastChanged": "v0.1.0",
      "keySignal": "Framing/rework now dominate",
      "supportingSignals": [
        "Rapid artifact generation with minimal marginal cost",
        "Increased verification and correction overhead in mature systems",
        "Shift in effort toward review, alignment, and validation"
      ],
      "challenges": [
        "Expert slowdowns due to verification tax",
        "Tool brittleness in complex, stateful systems"
      ],
      "q1Observations": [
        "AI coding tools (Claude Code, Cursor, Windsurf, GitHub Copilot Workspace) continued maturing, further compressing execution cost for bounded tasks.",
        "The METR RCT finding (experienced devs slower with AI in mature codebases) remains unrebutted and increasingly cited as the canonical counter\u2011signal. Notably, it *supports* the claim: verification and context\u2014not coding\u2014are the bottleneck.",
        "No new Tier A evidence contradicts the claim. Promotion to \"Supported\" blocked by lack of instrumented internal metrics on framing\u2011vs\u2011implementation ratio."
      ],
      "evaluationCriteria": [
        "Time spent framing vs implementing over time",
        "Ratio of rework due to misalignment vs technical defects"
      ],
      "evidence": [
        {
          "title": "The Mythical Man-Month",
          "author": "F.P. Brooks",
          "tier": "A",
          "summary": "Foundational software engineering text arguing that adding developers to late projects makes them later; demonstrates that communication and coordination\u2014not coding\u2014dominate software effort.",
          "type": "support"
        },
        {
          "title": "Code Complete",
          "author": "Steve McConnell",
          "tier": "A",
          "summary": "Comprehensive guide to software construction showing that design decisions, requirements clarity, and defect prevention matter more than raw coding speed.",
          "type": "support"
        },
        {
          "title": "AI | 2025 Stack Overflow Developer Survey",
          "author": "Stack Overflow",
          "url": "https://survey.stackoverflow.co/2025/ai/",
          "tier": "A",
          "summary": "Annual survey of 65,000+ developers; reveals that understanding existing code, documentation, and system context remain primary friction points\u2014not writing code.",
          "type": "support"
        },
        {
          "title": "Developer Experience Report 2025",
          "author": "Atlassian",
          "url": "https://www.atlassian.com/blog/developer/developer-experience-report-2025",
          "tier": "A",
          "summary": "Industry report on developer productivity; finds that context switching, unclear requirements, and collaboration overhead are top productivity drains.",
          "type": "support"
        },
        {
          "title": "The Impact of AI on Developer Productivity: Evidence from GitHub Copilot",
          "author": "Microsoft Research",
          "url": "https://www.microsoft.com/en-us/research/publication/the-impact-of-ai-on-developer-productivity-evidence-from-github-copilot/",
          "tier": "A",
          "summary": "Randomized controlled trial showing 55% faster task completion with Copilot on bounded coding tasks\u2014but measuring isolated coding, not full development lifecycle.",
          "type": "support"
        },
        {
          "title": "Measuring the Impact of Early-2025 AI on Experienced Open-Source Developer Productivity",
          "author": "Becker, Rush, Barnes, Rein",
          "url": "https://metr.org/blog/2025-07-10-early-2025-ai-experienced-os-dev-study/",
          "tier": "A",
          "summary": "Rigorous RCT finding that experienced developers were actually slower with AI tools in mature codebases\u2014verification overhead and context mismatch negated speed gains.",
          "type": "support"
        },
        {
          "title": "METR RCT above: experienced devs in mature repos were slower with early\u20112025 AI tools (verification + context tax).",
          "summary": "Directly challenges the claim by showing execution bottlenecks can increase with AI when verification costs dominate. The doctrine's response: this confirms that non-execution work (verification, context) is the actual constraint.",
          "type": "counter"
        }
      ],
      "skepticism": {
        "objection": "In many real organizations, execution is still slow due to legacy systems, regulatory drag, and understaffing\u2014not thinking quality.",
        "falsification": [
          "Tier A evidence showing sustained productivity gains end-to-end (not just coding tasks) from AI in mature, regulated systems *without* increased review/rework cost.",
          "Internal metrics showing implementation time dominating framing and rework for multiple quarters."
        ]
      },
      "metrics": [
        {
          "name": "Framing ratio",
          "description": "(time in intent/spec/design) \u00f7 (time in implementation)."
        },
        {
          "name": "Rework taxonomy",
          "description": "% rework due to *misalignment/spec ambiguity* vs *technical defects*."
        },
        {
          "name": "Review burden",
          "description": "median review time per PR; % of review comments that are semantic vs syntactic."
        }
      ]
    },
    {
      "id": "claim-2",
      "number": "Claim 2",
      "title": "Architecture becomes ontological, not just structural",
      "statement": "The primary architectural work shifts from pipelines and components to shared ontologies: vocabularies, invariants, constraints, and mental models.",
      "rationale": "Without shared meaning, faster execution increases divergence and coordination cost.",
      "status": "Active",
      "lastChanged": "v0.1.0",
      "keySignal": "Shared meaning > wiring",
      "supportingSignals": [
        "Need for registries, schemas, and canonical definitions",
        "Emergence of planning planes (intent, decision, execution, verification)"
      ],
      "challenges": [
        "Risk of over\u2011formalization",
        "Cultural resistance to explicit modeling"
      ],
      "q1Observations": [
        "Model Context Protocol (MCP) emerged as an open standard for agent\u2011tool interfaces\u2014essentially an ontological contract defining what tools exist, what they do, and how to invoke them. This directly instantiates the claim: shared meaning is becoming the architectural primitive for agentic systems.",
        "Agent frameworks (LangChain, CrewAI, Anthropic SDK) universally require explicit tool/resource schemas. Agents that lack a shared ontology with their environment fail reliably.",
        "Directional strengthening, but evidence remains mostly Tier B. No Tier A study yet isolates ontological architecture as the causal variable."
      ],
      "evaluationCriteria": [
        "Frequency of semantic vs technical disagreements",
        "Stability of interfaces and concepts over time"
      ],
      "evidence": [
        {
          "title": "Overview \u2022 Ontology",
          "author": "Palantir Foundry Docs",
          "url": "https://www.palantir.com/docs/foundry/ontology/overview",
          "tier": "B",
          "summary": "Describes Palantir's ontology layer\u2014a semantic framework where business objects, relationships, and actions are defined once and reused across all applications, collapsing integration complexity.",
          "type": "support"
        },
        {
          "title": "Ontologies \u2022 Overview",
          "author": "Palantir Foundry Docs",
          "url": "https://www.palantir.com/docs/foundry/ontologies/ontologies-overview",
          "tier": "B",
          "summary": "Technical documentation on building ontologies; shows how shared meaning (not shared pipelines) enables coordination at scale.",
          "type": "support"
        },
        {
          "title": "Ontology SDK (OSDK) \u2022 Overview",
          "author": "Palantir Foundry Docs",
          "url": "https://www.palantir.com/docs/foundry/ontology-sdk/overview",
          "tier": "B",
          "summary": "Developer SDK for ontology-driven applications; demonstrates how code generation from ontological definitions accelerates AI agent development.",
          "type": "support"
        },
        {
          "title": "General critique theme: over-formalization \u2192 documentation drag + rigidity. (See spec-driven critique set below.)",
          "summary": "Ontologies can calcify into heavyweight enterprise models that slow adaptation; the doctrine acknowledges this tension.",
          "type": "counter"
        }
      ],
      "skepticism": {
        "objection": "Ontologies overfit reality, calcify prematurely, and recreate heavyweight enterprise modeling failures of the past.",
        "falsification": [
          "Evidence that teams with minimal shared semantics outperform ontology-driven teams at scale.",
          "Repeated failures where explicit ontologies slow adaptation more than they reduce coordination cost."
        ]
      },
      "metrics": [
        {
          "name": "Semantic disagreement rate",
          "description": "number of disputes about definitions/invariants per sprint."
        },
        {
          "name": "Schema churn",
          "description": "changes per quarter to canonical vocabularies/schemas/event names."
        },
        {
          "name": "Interface stability",
          "description": "breaking-change frequency for key APIs/events."
        }
      ]
    },
    {
      "id": "claim-3",
      "number": "Claim 3",
      "title": "AI punishes vague thinking faster than humans do",
      "statement": "AI systems amplify ambiguity: unclear intent yields plausible but misaligned outcomes at higher velocity.",
      "rationale": "Probabilistic systems optimize for plausibility, not intention.",
      "status": "Strongly supported",
      "lastChanged": "v0.1.0",
      "keySignal": "Clarity is first-class skill",
      "supportingSignals": [
        "Correct\u2011looking but contextually wrong outputs",
        "High cleanup cost from underspecified tasks"
      ],
      "challenges": [
        "Short\u2011term productivity gains on bounded tasks"
      ],
      "q1Observations": [
        "\"Instruction files\" (CLAUDE.md, .cursorrules, .windsurfrules) became standard practice across AI coding tools. Their existence is direct evidence: teams that invest in explicit context and constraints consistently report better outcomes; those that don't, report frustration and waste.",
        "SWE\u2011bench results continue to show specification quality as the dominant predictor of AI solve rates, even as model capability improves.",
        "Spec\u2011driven development adoption expanded (Thoughtworks, Fowler, multiple tool vendors). The pattern is moving from \"emerging\" to \"conventional.\"",
        "No demotion signals. Status remains appropriate at highest level."
      ],
      "evaluationCriteria": [
        "Correlation between intent clarity and output quality",
        "Reduction in hallucination incidents with stronger constraints"
      ],
      "evidence": [
        {
          "title": "The Impact of AI on Developer Productivity: Evidence from GitHub Copilot",
          "author": "Microsoft Research",
          "url": "https://www.microsoft.com/en-us/research/publication/the-impact-of-ai-on-developer-productivity-evidence-from-github-copilot/",
          "tier": "A",
          "summary": "Shows AI excels on well-specified, bounded tasks; implicitly supports the claim that unclear requirements limit AI effectiveness.",
          "type": "support"
        },
        {
          "title": "AI writes code faster. Your job is still to prove it works.",
          "author": "Addy Osmani",
          "url": "https://addyosmani.com/blog/code-review-ai/",
          "tier": "A",
          "summary": "Chrome DevRel lead argues that AI shifts developer work toward review and verification; poor specs create \"plausible garbage\" at scale.",
          "type": "support"
        },
        {
          "title": "Developers remain willing but reluctant to use AI\u2026",
          "author": "Stack Overflow Blog",
          "url": "https://stackoverflow.blog/2025/12/29/developers-remain-willing-but-reluctant-to-use-ai-the-2025-developer-survey-results-are-here/",
          "tier": "A",
          "summary": "Survey analysis showing developers trust AI for boilerplate but distrust it for complex logic\u2014quality depends on task clarity.",
          "type": "support"
        },
        {
          "title": "The Copilot experiment shows large speedups on bounded tasks; i.e., vagueness is not always punished in toy or greenfield contexts.",
          "summary": "In well-defined, isolated coding exercises, vagueness may not hurt. The doctrine's scope is production systems where ambiguity compounds.",
          "type": "counter"
        }
      ],
      "skepticism": {
        "objection": "Skilled practitioners can iterate their way to clarity cheaply; vagueness is survivable with fast feedback loops.",
        "falsification": [
          "High-quality evidence that loosely specified AI-driven workflows consistently converge faster than spec-driven ones in complex domains.",
          "Internal data showing no correlation between intent clarity and AI correction rate."
        ]
      },
      "metrics": [
        {
          "name": "Spec completeness score",
          "description": "checklist-based completeness on intent docs (acceptance criteria present, invariants listed, negative cases defined)."
        },
        {
          "name": "AI correction rate",
          "description": "% of AI-generated artifacts requiring material correction."
        },
        {
          "name": "Hallucination incidence",
          "description": "tracked by category (wrong API usage, invented fields, incorrect assumptions)."
        }
      ]
    },
    {
      "id": "claim-4",
      "number": "Claim 4",
      "title": "Authority shifts toward harness authorship and outcomes",
      "statement": "Organizational authority increasingly derives from defining effective harnesses and delivering outcomes, not positional hierarchy or execution volume.",
      "rationale": "Harnesses encode bets, constraints, and governance. Those who define them shape reality.",
      "status": "Emerging",
      "lastChanged": "v0.1.0",
      "keySignal": "Constraints > hierarchy",
      "supportingSignals": [
        "Reputation\u2011based authorship",
        "Outcome\u2011driven legitimacy"
      ],
      "challenges": [
        "Risk of informal power concentration",
        "Need for arbitration mechanisms"
      ],
      "q1Observations": [
        "\"Plan\u2011then\u2011execute\" is now the default pattern in agentic workflows. Claude Code's planning mode, Devin\u2011style agents, and Copilot Workspace all structurally separate the person defining intent/constraints from the agent executing. Authority flows demonstrably to whoever defines the plan and acceptance criteria.",
        "Spec\u2011driven development moved from \"interesting pattern\" to \"widely discussed practice\" (Thoughtworks, Fowler, tool vendors building spec\u2011first workflows).",
        "Promotion to \"Supported\" still requires Tier A evidence on the *authority mechanism* specifically (not just \"specs are useful\"). Existing sources remain Tier B/C. Close, but not yet over the threshold."
      ],
      "evaluationCriteria": [
        "Who defines constraints vs who executes",
        "How conflicts are resolved"
      ],
      "evidence": [
        {
          "title": "Spec-driven development: Unpacking one of 2025's key new AI-assisted engineering practices",
          "author": "Thoughtworks",
          "url": "https://www.thoughtworks.com/insights/blog/agile-engineering-practices/spec-driven-development-unpacking-2025-new-engineering-practices",
          "tier": "B",
          "summary": "Thoughtworks analysis of emerging \"spec-driven development\" pattern where upfront specification becomes the primary artifact; positions spec authors as key decision-makers.",
          "type": "support"
        },
        {
          "title": "Understanding Spec-Driven-Development: Kiro, spec-kit, and Tessl",
          "author": "Martin Fowler / Thoughtworks",
          "url": "https://martinfowler.com/articles/exploring-gen-ai/sdd-3-tools.html",
          "tier": "B",
          "summary": "Martin Fowler's exploration of spec-driven tools; shows how those who define specs and validation criteria shape what gets built.",
          "type": "support"
        },
        {
          "title": "AI writes code faster\u2026 prove it works",
          "author": "Addy Osmani",
          "url": "https://addyosmani.com/blog/code-review-ai/",
          "tier": "B",
          "summary": "Argues that review and validation\u2014not coding\u2014become the valued activities; authority flows to those who define correctness criteria.",
          "type": "support"
        },
        {
          "title": "Spec-driven workflows can re-centralize power into \"spec priests,\" and can create a false sense of correctness without strong tests.",
          "summary": "Risk that \"harness authorship\" becomes gatekeeping without accountability; doctrine must guard against this failure mode.",
          "type": "counter"
        },
        {
          "title": "Putting Spec Kit Through Its Paces\u2026",
          "author": "Scott Logic \u2014 2025-11-26",
          "url": "https://blog.scottlogic.com/2025/11/26/putting-spec-kit-through-its-paces-radical-idea-or-reinvented-waterfall.html",
          "tier": "C",
          "summary": "Critical evaluation finding that spec-kit reintroduces waterfall rigidity; specs became documentation debt rather than living guidance.",
          "type": "counter"
        },
        {
          "title": "Spec-Driven Development: The Waterfall Strikes Back",
          "author": "marmelab \u2014 2025-11-12",
          "url": "https://marmelab.com/blog/2025/11/12/spec-driven-development-waterfall-strikes-back.html",
          "tier": "C",
          "summary": "Argues that over-specified upfront workflows recreate waterfall's worst pathologies\u2014slow iteration, delayed feedback, false certainty.",
          "type": "counter"
        }
      ],
      "skepticism": {
        "objection": "Power still accrues to people managers and budget holders; harness authorship is a technical detail, not authority.",
        "falsification": [
          "Organizational case studies where harness authorship has little or no influence on prioritization, outcomes, or decision rights.",
          "Persistent misalignment between harness definitions and shipped outcomes."
        ]
      },
      "metrics": [
        {
          "name": "Harness authorship concentration",
          "description": "distribution of who authors/maintains harnesses (Gini coefficient optional)."
        },
        {
          "name": "Outcome ownership clarity",
          "description": "% of workstreams with explicit owner, success metric, and validation plan."
        },
        {
          "name": "Arbitration load",
          "description": "frequency and type of conflicts requiring escalation."
        }
      ]
    },
    {
      "id": "claim-5a",
      "number": "Claim 5a",
      "title": "Roles converge upward in greenfield and small\u2011team contexts",
      "statement": "In greenfield, startup, and small\u2011team contexts, AI makes narrowly defined execution functions economically obsolete faster than it creates new narrow roles, increasing demand for generalists with architectural judgment.",
      "rationale": "Small teams already reward breadth. AI amplifies this by collapsing the cost of tasks that previously justified specialists (boilerplate code, standard UI, routine testing). The result is fewer, broader roles\u2014not a hollowed middle.",
      "status": "Emerging",
      "lastChanged": "v1.0.0",
      "keySignal": "Generalists rise in fluid contexts",
      "supportingSignals": [
        "Brynjolfsson et al. (NBER/QJE): AI tools compress skill differentials, enabling faster upward mobility\u2014most pronounced in smaller, less hierarchical settings.",
        "Practitioner reports from startups and small product teams consistently describe broadening role scopes.",
        "LinkedIn data on \"lattice\" career paths replacing ladders (Aneesh Raman)."
      ],
      "challenges": [
        "Survivorship bias: small teams that succeed with generalists are more visible than those that fail.",
        "Selection effect: generalists may self\u2011select into small teams, not be created by AI."
      ],
      "q1Observations": [
        "The pattern of \"one person + AI doing the work of a small team\" became a widespread narrative in Q1 2026 (indie developers, solo founders, small product teams). Directionally supportive, but largely Tier C/D evidence.",
        "No Tier A study yet isolates the causal mechanism in this specific context."
      ],
      "evaluationCriteria": [
        "Worktype breadth per person in small\u2011team settings",
        "Time\u2011to\u2011impact for new generalist contributors",
        "Ratio of specialist vs generalist hires in sub\u201150\u2011person orgs"
      ],
      "splitNote": "Split from original Claim 5 in v1.0.0 (Q1 2026 review). The original \"Contentious\" status reflected strong evidence on both sides; the [Split Rule](#status-rules-how-claims-change-state) was applied to separate the contexts where the evidence diverges.",
      "evidence": [
        {
          "title": "Generative AI at Work",
          "author": "Brynjolfsson, Li, Raymond",
          "url": "https://www.nber.org/papers/w31161",
          "tier": "A",
          "summary": "NBER study of 5,000+ customer service agents; AI tools boosted productivity most for novice workers, compressing skill differentials and enabling faster upward mobility. Effect strongest in less hierarchical settings.",
          "type": "support"
        },
        {
          "title": "LinkedIn's Aneesh Raman says the career ladder is disappearing\u2026",
          "author": "Fast Company",
          "url": "https://www.fastcompany.com/91375183/linkedin-aneesh-raman-ai-career-ladders",
          "tier": "A",
          "summary": "LinkedIn's VP of Workforce Development argues traditional career ladders are becoming \"lattices\"\u2014generalist agility matters more than specialist depth.",
          "type": "support"
        },
        {
          "title": "How artificial intelligence impacts the US labor market",
          "author": "MIT Sloan",
          "url": "https://mitsloan.mit.edu/ideas-made-to-matter/how-artificial-intelligence-impacts-us-labor-market",
          "tier": "A",
          "summary": "MIT analysis showing AI effects are gradual, task-specific, and often complementary; convergence may be slower than practitioner narratives suggest.",
          "type": "counter"
        }
      ],
      "skepticism": {
        "objection": "Convergence in small teams is survivorship bias \u2014 we see the successes, not the failures. Generalists self\u2011select into small teams; AI doesn't create them.",
        "falsification": [
          "Evidence that small teams with AI\u2011augmented specialists consistently outperform generalist teams.",
          "Longitudinal data showing no increase in role breadth in startup/small\u2011team contexts post\u2011AI adoption."
        ]
      },
      "metrics": [
        {
          "name": "Worktype breadth per person",
          "description": "count of domains touched per quarter (design, FE, BE, infra, data, ops) in teams <15 people."
        },
        {
          "name": "Generalist hire ratio",
          "description": "% of hires with cross\u2011domain expectations vs single\u2011domain in sub\u201150\u2011person orgs."
        },
        {
          "name": "Time\u2011to\u2011impact",
          "description": "onboarding slope for new generalist contributors in small\u2011team settings."
        }
      ]
    },
    {
      "id": "claim-5b",
      "number": "Claim 5b",
      "title": "Roles bifurcate in large enterprise and regulated contexts",
      "statement": "In large enterprises and regulated industries, AI may produce role bifurcation rather than convergence: a smaller tier of elite generalists who define harnesses and systems, and a larger tier of commoditized execution roles whose tasks are increasingly AI\u2011mediated and narrowly scoped.",
      "rationale": "Large organizations have structural incentives to specialize and stratify. AI may reinforce this by making junior execution cheaper (not eliminated), while concentrating judgment and autonomy at the top. The \"broken bottom rung\" risk: if entry\u2011level work is automated, the pipeline that produces senior generalists may narrow.",
      "status": "Proposed",
      "lastChanged": "v1.0.0",
      "keySignal": "Hollowed middle; elite + commodity",
      "supportingSignals": [
        "Reports of reduced junior developer hiring at some large tech companies (Q4 2025\u2013Q1 2026).",
        "ADP payroll data showing routine cognitive tasks declining faster than manual ones.",
        "The \"broken bottom rung\" concern: if AI handles entry\u2011level tasks, how do juniors develop the judgment to become seniors?",
        "Stanford \"Canaries in the Coal Mine\" paper: specific task categories declining while orchestration roles grow\u2014but growth is concentrated at senior levels."
      ],
      "challenges": [
        "NY Fed research: aggregate employment stable so far; macro data does not yet show bifurcation.",
        "MIT Sloan analysis: AI effects are gradual, task\u2011specific, and often complementary.",
        "Some enterprises report *increased* junior hiring for AI\u2011augmented roles (data labeling, prompt engineering, validation)."
      ],
      "q1Observations": [
        "The bifurcation narrative gained traction in Q1 2026 industry discourse, but remains under\u2011evidenced at Tier A level.",
        "No longitudinal labor dataset yet confirms or refutes bifurcation in enterprise contexts specifically.",
        "This claim is deliberately positioned as \"Proposed\" to flag it for rigorous tracking without overstating confidence."
      ],
      "evaluationCriteria": [
        "Junior\u2011to\u2011senior hiring ratio changes in enterprises with >500 employees",
        "Skill distribution changes within large engineering orgs (breadth vs depth)",
        "Wage distribution shifts (compression vs polarization)",
        "\"Broken bottom rung\" indicator: time\u2011to\u2011senior for new hires over time"
      ],
      "splitNote": "Split from original Claim 5 in v1.0.0 (Q1 2026 review).",
      "evidence": [
        {
          "title": "Canaries in the Coal Mine? Six Facts\u2026",
          "author": "Brynjolfsson et al.",
          "url": "https://digitaleconomy.stanford.edu/wp-content/uploads/2025/08/Canaries_BrynjolfssonChandarChen.pdf",
          "tier": "A",
          "summary": "Stanford research tracking early labor market signals; finds specific task categories declining while orchestration roles grow\u2014but growth concentrated at senior levels in larger organizations.",
          "type": "support"
        },
        {
          "title": "Yes, AI is affecting employment. Here's the data.",
          "author": "ADP Research",
          "url": "https://www.adpresearch.com/yes-ai-is-affecting-employment-heres-the-data/",
          "tier": "A",
          "summary": "ADP payroll data analysis showing shifts in job composition; routine cognitive tasks declining faster than manual ones, with larger effects in bigger firms.",
          "type": "support"
        },
        {
          "title": "AI not affecting job market much so far, New York Fed says",
          "author": "Reuters",
          "tier": "A",
          "summary": "Macro labor data shows aggregate employment stable; warns against overstating bifurcation velocity.",
          "type": "counter"
        },
        {
          "title": "How artificial intelligence impacts the US labor market",
          "author": "MIT Sloan",
          "url": "https://mitsloan.mit.edu/ideas-made-to-matter/how-artificial-intelligence-impacts-us-labor-market",
          "tier": "A",
          "summary": "MIT analysis showing AI effects are gradual, task-specific, and often complementary; cautions against deterministic bifurcation narratives.",
          "type": "counter"
        }
      ],
      "skepticism": {
        "objection": "Bifurcation is an overreaction to short\u2011term hiring freezes. Enterprises will adapt by creating new mid\u2011level roles (AI trainers, prompt engineers, validation specialists) that fill the middle.",
        "falsification": [
          "Longitudinal enterprise labor data showing stable or growing mid\u2011level execution roles despite AI adoption.",
          "Evidence that enterprises are creating *new* mid\u2011level roles at a rate that offsets the decline of existing ones.",
          "Internal evidence that junior\u2011to\u2011senior pipelines remain healthy in AI\u2011heavy enterprise teams."
        ]
      },
      "metrics": [
        {
          "name": "Junior\u2011to\u2011senior hiring ratio",
          "description": "tracked per quarter in orgs >500 employees."
        },
        {
          "name": "Function displacement index",
          "description": "tasks automated or eliminated vs tasks created, segmented by seniority level."
        },
        {
          "name": "\"Broken bottom rung\" indicator",
          "description": "time\u2011to\u2011senior for new hires over time; watch for pipeline narrowing."
        },
        {
          "name": "Wage distribution",
          "description": "compression vs polarization in engineering compensation bands."
        }
      ]
    },
    {
      "id": "claim-6",
      "number": "Claim 6",
      "title": "Safe autonomy requires seasoned intent and explicit validation",
      "statement": "Agent autonomy is viable only when direction, reasoning, and validation are established *before* execution.",
      "rationale": "Autonomy applies to execution, not thinking.",
      "status": "Emerging",
      "lastChanged": "v1.0.0",
      "keySignal": "Vendor convergence on bounded autonomy",
      "supportingSignals": [
        "Success of phase\u2011bounded autonomous runs",
        "Failure of free\u2011form agent behavior"
      ],
      "challenges": [
        "Overconfidence in tooling",
        "Governance gaps"
      ],
      "q1Observations": [
        "Multiple independent vendors converged on phase\u2011bounded autonomy with explicit validation gates: Claude Code (plan mode + human approval checkpoints), Devin (task decomposition with verification), Copilot Workspace (spec \u2192 plan \u2192 implement \u2192 validate pipeline). This convergence is a strong Tier B signal\u2014it's not one vendor's opinion but an industry pattern.",
        "Anthropic's Agent SDK documentation and \"Building Effective Agents\" guidance explicitly recommend human\u2011in\u2011the\u2011loop checkpoints and bounded autonomy scopes.",
        "The Veracode study (48% of AI\u2011assisted tasks introducing vulnerabilities without strong validation) remains unrebutted. No credible Tier A study shows agents achieving low defect rates in open\u2011ended tasks without harnesses.",
        "The Klarna cautionary case (autonomy without adequate validation \u2192 service quality regression) continues to be cited as a canonical failure mode.",
        "**Status promoted** from \"Early validation\" to \"Emerging\" based on: 1 Tier A/B source (Veracode) + 2+ Tier B sources (vendor architecture convergence, Anthropic agent guidance) on the mechanism; counter\u2011evidence reviewed; \"autonomous run success rate\" is measurable internally."
      ],
      "evaluationCriteria": [
        "Error rates in autonomous vs supervised runs",
        "Quality of post\u2011hoc review"
      ],
      "evidence": [
        {
          "title": "2025 GenAI Code Security Report",
          "author": "Veracode",
          "url": "https://www.veracode.com/resources/analyst-reports/2025-genai-code-security-report/",
          "tier": "A",
          "summary": "Analysis of AI-generated code security; finds 48% of AI-assisted development tasks introduce vulnerabilities without strong validation gates.",
          "type": "support"
        },
        {
          "title": "OWASP Top 10:2025",
          "author": "OWASP",
          "url": "https://owasp.org/Top10/2025/",
          "tier": "A",
          "summary": "Updated web security risks; increasingly includes AI-specific attack surfaces and emphasizes validation as the primary defense.",
          "type": "support"
        },
        {
          "title": "SWE-bench",
          "author": "benchmark repo",
          "url": "https://github.com/swe-bench/SWE-bench",
          "tier": "A",
          "summary": "AI coding benchmark; shows that autonomous success depends heavily on problem specification quality and test coverage.",
          "type": "support"
        },
        {
          "title": "AI writes code faster\u2026 prove it works",
          "author": "Addy Osmani",
          "url": "https://addyosmani.com/blog/code-review-ai/",
          "tier": "A",
          "summary": "Practical guide arguing AI output requires more rigorous review, not less\u2014speed without validation produces technical debt.",
          "type": "support"
        },
        {
          "title": "Klarna is reassigning engineers and marketers to customer support after its AI bet went too far",
          "author": "Business Insider",
          "tier": "C",
          "summary": "Real-world example of autonomy without adequate validation leading to service quality regression; demonstrates consequences of insufficient human oversight.",
          "type": "counter"
        },
        {
          "title": "Putting Spec Kit Through Its Paces\u2026",
          "author": "Scott Logic",
          "url": "https://blog.scottlogic.com/2025/11/26/putting-spec-kit-through-its-paces-radical-idea-or-reinvented-waterfall.html",
          "tier": "A",
          "summary": "Critical evaluation finding that spec-kit reintroduces waterfall rigidity; specs became documentation debt rather than living guidance.",
          "type": "counter"
        },
        {
          "title": "Spec-Driven Development: The Waterfall Strikes Back",
          "author": "marmelab",
          "url": "https://marmelab.com/blog/2025/11/12/spec-driven-development-waterfall-strikes-back.html",
          "tier": "A",
          "summary": "Argues that over-specified upfront workflows recreate waterfall's worst pathologies\u2014slow iteration, delayed feedback, false certainty.",
          "type": "counter"
        },
        {
          "title": "Valve Corporation: Strategy tipping points and thresholds",
          "author": "Teppo Felin",
          "url": "https://www.jorgdesign.net/article/view/20157",
          "tier": "A",
          "summary": "Academic study of Valve's flat, project-based structure; analyzes how peer-based authority and self-selection can work at scale.",
          "type": "counter"
        },
        {
          "title": "PDF \u2014",
          "url": "https://www.jorgdesign.net/article/download/20157/18615/48160",
          "summary": "Full academic paper with organizational theory framework for analyzing emergent authority structures.",
          "type": "counter"
        },
        {
          "title": "Handbook for New Employees (Valve) \u2014 2012 \u2014",
          "url": "https://www.valvesoftware.com/company/Valve_Handbook.pdf",
          "summary": "Primary source document showing how Valve operationalizes flat hierarchy, project self-selection, and peer-based accountability.",
          "type": "counter"
        },
        {
          "title": "Stack Overflow blog post (survey synthesis) \u2014",
          "url": "https://stackoverflow.blog/2025/12/29/developers-remain-willing-but-reluctant-to-use-ai-the-2025-developer-survey-results-are-here/",
          "summary": "Editorial analysis of the 2025 developer survey; highlights the trust gap between AI capability and developer confidence.",
          "type": "counter"
        },
        {
          "title": "Veracode report press coverage (announcement) \u2014",
          "url": "https://www.businesswire.com/news/home/20250730694951/en/AI-Generated-Code-Poses-Major-Security-Risks-in-Nearly-Half-of-All-Development-Tasks-Veracode-Research-Reveals",
          "summary": "Press release for the Veracode security study; accessible summary of the 48% vulnerability finding in AI-assisted code.",
          "type": "counter"
        },
        {
          "title": "The New Stack (review bottleneck discussion) \u2014",
          "url": "https://thenewstack.io/is-ai-creating-a-new-code-review-bottleneck-for-senior-engineers/",
          "summary": "Industry reporting on emerging \"review bottleneck\" where senior engineers spend disproportionate time validating AI output from junior contributors.",
          "type": "counter"
        }
      ],
      "skepticism": {
        "objection": "Improved models and self-correcting agents will reduce the need for heavy upfront intent and human validation.",
        "falsification": [
          "Benchmarks showing agents achieving low defect and security rates in open-ended tasks without strong harnesses.",
          "Internal deployments where free-form autonomy outperforms phase-bounded autonomy on reliability and safety metrics."
        ]
      },
      "metrics": [
        {
          "name": "Autonomous run success rate",
          "description": "% runs that pass validation without human intervention."
        },
        {
          "name": "Defect escape rate",
          "description": "production issues attributable to AI-generated changes."
        },
        {
          "name": "Security gate catches",
          "description": "vuln findings per AI-generated change-set vs human-authored baseline."
        }
      ]
    }
  ],
  "closingPrinciple": "Infinite capability without constrained intent does not produce success. It produces noise at scale."
}
</script>


---

## Executive Summary

**Core thesis:** Technology roles are shifting from *doing* to *defining*—execution is abundant; alignment, framing, and validation are the new bottlenecks.

**Why this matters:** AI amplifies both clarity and confusion. Organizations that formalize intent, constraints, and shared meaning will outpace those that don't.

**What leaders should take away:** The six claims below are falsifiable bets about how work is changing. They're evidence-backed, regularly reviewed, and expected to evolve.

*Reading time: ~15 min for core content; reference sections collapsed for optional deep-dives.*

---

## Contents

- [Executive Summary](#executive-summary)
- [Claims Dashboard](#claims-dashboard)
- [Purpose](#purpose-of-this-document)
- [Scope & Non-Goals](#scope-and-nongoals)
- [Core Thesis](#core-thesis-current)
- [Definitions](#definitions-working)
- [Foundational Claims](#foundational-claims)
  - [Claim 1: Execution constraint](#claim-1--execution-is-no-longer-the-dominant-constraint)
  - [Claim 2: Ontological architecture](#claim-2--architecture-becomes-ontological-not-just-structural)
  - [Claim 3: Vagueness penalty](#claim-3--ai-punishes-vague-thinking-faster-than-humans-do)
  - [Claim 4: Authority shift](#claim-4--authority-shifts-toward-harness-authorship-and-outcomes)
  - [Claim 5a: Role convergence (greenfield)](#claim-5a--roles-converge-upward-in-greenfield-and-small-team-contexts)
  - [Claim 5b: Role bifurcation (enterprise)](#claim-5b--roles-bifurcate-in-large-enterprise-and-regulated-contexts)
  - [Claim 6: Safe autonomy](#claim-6--safe-autonomy-requires-seasoned-intent-and-explicit-validation)
- [Relationship to Arbuckle](#relationship-to-arbuckle)
- [Evidence & Sources](#evidence-registry-annotated) *(collapsed)*
- [Status Rules](#status-rules-how-claims-change-state) *(collapsed)*
- [Metrics](#metrics-and-instrumentation-appendix-internal-auditability) *(collapsed)*
- [Telecom Translation](#telecom-translation-layer-how-this-doctrine-maps-to-our-domain) *(collapsed)*
- [Skeptic's Appendix](#skeptics-appendix-best-faith-challenges) *(collapsed)*
- [Review Cadence](#review-cadence)
- [Changelog](#changelog-historical-record) *(collapsed)*

---

## Claims Dashboard

| # | Claim | Status | Last Changed | Key Signal |
|---|-------|--------|--------------|------------|
| 1 | Execution is no longer dominant constraint | Active | v0.1.0 | Framing/rework now dominate |
| 2 | Architecture becomes ontological | Active | v0.1.0 | Shared meaning > wiring |
| 3 | AI punishes vague thinking faster | **Strongly supported** | v0.1.0 | Clarity is first-class skill |
| 4 | Authority shifts to harness authorship | Emerging | v0.1.0 | Constraints > hierarchy |
| 5a | Roles converge upward (greenfield / small teams) | Emerging | v1.0.0 | Generalists rise in fluid contexts |
| 5b | Roles bifurcate (large enterprise / regulated) | Proposed | v1.0.0 | Hollowed middle; elite + commodity |
| 6 | Safe autonomy requires seasoned intent | **Emerging** | v1.0.0 | Vendor convergence on bounded autonomy |

---

## Purpose of this document

This document is not a manifesto and not a prediction market.

It is a **doctrine**: a structured set of claims about how AI‑assisted development is changing the nature of work, paired with explicit assumptions, supporting evidence, counter‑evidence, and evaluation criteria.

Its goals:
- Provide a stable intellectual backbone for future talks, decisions, and tools (e.g., Arbuckle)
- Make beliefs **auditable over time** as evidence accumulates
- Separate signal from hype without retreating into denial
- Force clarity where intuition alone would otherwise suffice

This document is expected to change.

---

## Scope and non‑goals

**In scope**
- Knowledge work and software‑driven organizations
- Product, design, engineering, and leadership roles
- AI systems as *execution amplifiers*, not moral agents
- Near‑ to mid‑term horizons (0–5 years)

**Out of scope**
- AGI timelines
- Societal collapse / utopia narratives
- Moral philosophy of artificial minds
- Vendor‑specific forecasts

---

## Core thesis (current)

> [!IMPORTANT]
> **Technology roles are shifting from discrete execution to ontological orchestration: the definition, constraint, and sequencing of meaning in systems where execution is increasingly abundant.**

Execution is no longer the primary bottleneck.

Alignment, framing, verification, and shared world‑models are.

---

## Definitions (working)

**Ontological orchestration**  
The act of defining *what exists*, *what matters*, *how components relate*, and *what constitutes correctness* in a system—before and during execution.

**Harness**  
A structured package of intent, constraints, artifacts, and validation mechanisms that bounds and guides execution (human or agentic).

**Intent hypothesis**  
A falsifiable statement describing a believed problem, its context, constraints, and success criteria.

**Situated authorship**  
Authorship determined by surface‑area expertise and problem context rather than formal role.

---

<!-- pagebreak -->

## Foundational claims

Each claim is intentionally crisp. Each includes rationale, current support, known challenges, and evaluation signals.

---

### Claim 1 — Execution is no longer the dominant constraint

**Statement**  
For most software‑driven organizations, the cost of producing artifacts (code, designs, drafts) is falling faster than the cost of deciding *what should exist* and *how it should behave*.

**Rationale**  
AI systems dramatically reduce realization latency, enabling rapid generation and iteration. This amplifies the cost of poor framing and weak constraints.

**Supporting signals**  
- Rapid artifact generation with minimal marginal cost
- Increased verification and correction overhead in mature systems
- Shift in effort toward review, alignment, and validation

**Challenges / counter‑signals**  
- Expert slowdowns due to verification tax
- Tool brittleness in complex, stateful systems

**Q1 2026 observations**
- AI coding tools (Claude Code, Cursor, Windsurf, GitHub Copilot Workspace) continued maturing, further compressing execution cost for bounded tasks.
- The METR RCT finding (experienced devs slower with AI in mature codebases) remains unrebutted and increasingly cited as the canonical counter‑signal. Notably, it *supports* the claim: verification and context—not coding—are the bottleneck.
- No new Tier A evidence contradicts the claim. Promotion to "Supported" blocked by lack of instrumented internal metrics on framing‑vs‑implementation ratio.

**Evaluation criteria**
- Time spent framing vs implementing over time
- Ratio of rework due to misalignment vs technical defects

**Status**: Active / Under evaluation

---

### Claim 2 — Architecture becomes ontological, not just structural

**Statement**  
The primary architectural work shifts from pipelines and components to shared ontologies: vocabularies, invariants, constraints, and mental models.

**Rationale**  
Without shared meaning, faster execution increases divergence and coordination cost.

**Supporting signals**  
- Need for registries, schemas, and canonical definitions
- Emergence of planning planes (intent, decision, execution, verification)

**Challenges / counter‑signals**  
- Risk of over‑formalization
- Cultural resistance to explicit modeling

**Q1 2026 observations**
- Model Context Protocol (MCP) emerged as an open standard for agent‑tool interfaces—essentially an ontological contract defining what tools exist, what they do, and how to invoke them. This directly instantiates the claim: shared meaning is becoming the architectural primitive for agentic systems.
- Agent frameworks (LangChain, CrewAI, Anthropic SDK) universally require explicit tool/resource schemas. Agents that lack a shared ontology with their environment fail reliably.
- Directional strengthening, but evidence remains mostly Tier B. No Tier A study yet isolates ontological architecture as the causal variable.

**Evaluation criteria**
- Frequency of semantic vs technical disagreements
- Stability of interfaces and concepts over time

**Status**: Active

---

### Claim 3 — AI punishes vague thinking faster than humans do

**Statement**  
AI systems amplify ambiguity: unclear intent yields plausible but misaligned outcomes at higher velocity.

**Rationale**  
Probabilistic systems optimize for plausibility, not intention.

**Supporting signals**  
- Correct‑looking but contextually wrong outputs
- High cleanup cost from underspecified tasks

**Challenges / counter‑signals**  
- Short‑term productivity gains on bounded tasks

**Q1 2026 observations**
- "Instruction files" (CLAUDE.md, .cursorrules, .windsurfrules) became standard practice across AI coding tools. Their existence is direct evidence: teams that invest in explicit context and constraints consistently report better outcomes; those that don't, report frustration and waste.
- SWE‑bench results continue to show specification quality as the dominant predictor of AI solve rates, even as model capability improves.
- Spec‑driven development adoption expanded (Thoughtworks, Fowler, multiple tool vendors). The pattern is moving from "emerging" to "conventional."
- No demotion signals. Status remains appropriate at highest level.

**Evaluation criteria**
- Correlation between intent clarity and output quality
- Reduction in hallucination incidents with stronger constraints

**Status**: Strongly supported

---

### Claim 4 — Authority shifts toward harness authorship and outcomes

**Statement**  
Organizational authority increasingly derives from defining effective harnesses and delivering outcomes, not positional hierarchy or execution volume.

**Rationale**  
Harnesses encode bets, constraints, and governance. Those who define them shape reality.

**Supporting signals**  
- Reputation‑based authorship
- Outcome‑driven legitimacy

**Challenges / counter‑signals**  
- Risk of informal power concentration
- Need for arbitration mechanisms

**Q1 2026 observations**
- "Plan‑then‑execute" is now the default pattern in agentic workflows. Claude Code's planning mode, Devin‑style agents, and Copilot Workspace all structurally separate the person defining intent/constraints from the agent executing. Authority flows demonstrably to whoever defines the plan and acceptance criteria.
- Spec‑driven development moved from "interesting pattern" to "widely discussed practice" (Thoughtworks, Fowler, tool vendors building spec‑first workflows).
- Promotion to "Supported" still requires Tier A evidence on the *authority mechanism* specifically (not just "specs are useful"). Existing sources remain Tier B/C. Close, but not yet over the threshold.

**Evaluation criteria**
- Who defines constraints vs who executes
- How conflicts are resolved

**Status**: Emerging

---

### Claim 5a — Roles converge upward in greenfield and small‑team contexts

> *Split from original Claim 5 in v1.0.0 (Q1 2026 review). The original "Contentious" status reflected strong evidence on both sides; the [Split Rule](#status-rules-how-claims-change-state) was applied to separate the contexts where the evidence diverges.*

**Statement**
In greenfield, startup, and small‑team contexts, AI makes narrowly defined execution functions economically obsolete faster than it creates new narrow roles, increasing demand for generalists with architectural judgment.

**Rationale**
Small teams already reward breadth. AI amplifies this by collapsing the cost of tasks that previously justified specialists (boilerplate code, standard UI, routine testing). The result is fewer, broader roles—not a hollowed middle.

**Supporting signals**
- Brynjolfsson et al. (NBER/QJE): AI tools compress skill differentials, enabling faster upward mobility—most pronounced in smaller, less hierarchical settings.
- Practitioner reports from startups and small product teams consistently describe broadening role scopes.
- LinkedIn data on "lattice" career paths replacing ladders (Aneesh Raman).

**Challenges / counter‑signals**
- Survivorship bias: small teams that succeed with generalists are more visible than those that fail.
- Selection effect: generalists may self‑select into small teams, not be created by AI.

**Q1 2026 observations**
- The pattern of "one person + AI doing the work of a small team" became a widespread narrative in Q1 2026 (indie developers, solo founders, small product teams). Directionally supportive, but largely Tier C/D evidence.
- No Tier A study yet isolates the causal mechanism in this specific context.

**Evaluation criteria**
- Worktype breadth per person in small‑team settings
- Time‑to‑impact for new generalist contributors
- Ratio of specialist vs generalist hires in sub‑50‑person orgs

**Status**: Emerging

---

### Claim 5b — Roles bifurcate in large enterprise and regulated contexts

> *Split from original Claim 5 in v1.0.0 (Q1 2026 review).*

**Statement**
In large enterprises and regulated industries, AI may produce role bifurcation rather than convergence: a smaller tier of elite generalists who define harnesses and systems, and a larger tier of commoditized execution roles whose tasks are increasingly AI‑mediated and narrowly scoped.

**Rationale**
Large organizations have structural incentives to specialize and stratify. AI may reinforce this by making junior execution cheaper (not eliminated), while concentrating judgment and autonomy at the top. The "broken bottom rung" risk: if entry‑level work is automated, the pipeline that produces senior generalists may narrow.

**Supporting signals**
- Reports of reduced junior developer hiring at some large tech companies (Q4 2025–Q1 2026).
- ADP payroll data showing routine cognitive tasks declining faster than manual ones.
- The "broken bottom rung" concern: if AI handles entry‑level tasks, how do juniors develop the judgment to become seniors?
- Stanford "Canaries in the Coal Mine" paper: specific task categories declining while orchestration roles grow—but growth is concentrated at senior levels.

**Challenges / counter‑signals**
- NY Fed research: aggregate employment stable so far; macro data does not yet show bifurcation.
- MIT Sloan analysis: AI effects are gradual, task‑specific, and often complementary.
- Some enterprises report *increased* junior hiring for AI‑augmented roles (data labeling, prompt engineering, validation).

**Q1 2026 observations**
- The bifurcation narrative gained traction in Q1 2026 industry discourse, but remains under‑evidenced at Tier A level.
- No longitudinal labor dataset yet confirms or refutes bifurcation in enterprise contexts specifically.
- This claim is deliberately positioned as "Proposed" to flag it for rigorous tracking without overstating confidence.

**Evaluation criteria**
- Junior‑to‑senior hiring ratio changes in enterprises with >500 employees
- Skill distribution changes within large engineering orgs (breadth vs depth)
- Wage distribution shifts (compression vs polarization)
- "Broken bottom rung" indicator: time‑to‑senior for new hires over time

**Status**: Proposed

---

### Claim 6 — Safe autonomy requires seasoned intent and explicit validation

**Statement**  
Agent autonomy is viable only when direction, reasoning, and validation are established *before* execution.

**Rationale**  
Autonomy applies to execution, not thinking.

**Supporting signals**  
- Success of phase‑bounded autonomous runs
- Failure of free‑form agent behavior

**Challenges / counter‑signals**  
- Overconfidence in tooling
- Governance gaps

**Q1 2026 observations**
- Multiple independent vendors converged on phase‑bounded autonomy with explicit validation gates: Claude Code (plan mode + human approval checkpoints), Devin (task decomposition with verification), Copilot Workspace (spec → plan → implement → validate pipeline). This convergence is a strong Tier B signal—it's not one vendor's opinion but an industry pattern.
- Anthropic's Agent SDK documentation and "Building Effective Agents" guidance explicitly recommend human‑in‑the‑loop checkpoints and bounded autonomy scopes.
- The Veracode study (48% of AI‑assisted tasks introducing vulnerabilities without strong validation) remains unrebutted. No credible Tier A study shows agents achieving low defect rates in open‑ended tasks without harnesses.
- The Klarna cautionary case (autonomy without adequate validation → service quality regression) continues to be cited as a canonical failure mode.
- **Status promoted** from "Early validation" to "Emerging" based on: 1 Tier A/B source (Veracode) + 2+ Tier B sources (vendor architecture convergence, Anthropic agent guidance) on the mechanism; counter‑evidence reviewed; "autonomous run success rate" is measurable internally.

**Evaluation criteria**
- Error rates in autonomous vs supervised runs
- Quality of post‑hoc review

**Status**: Emerging *(promoted from Early validation in v1.0.0)*

---

<!-- pagebreak -->

## Relationship to Arbuckle

Arbuckle is a **reference implementation** of these claims, not proof of them.

It explores:
- Planning planes as first‑class artifacts
- Harness selection and maturity thresholds
- Machine‑readable intent and verification

Failures in Arbuckle are evidence against the doctrine and should be treated as such.

---

<details>
<summary><strong>📚 Evidence Registry</strong> — Supporting and challenging evidence per claim</summary>

## Evidence registry (annotated)

The following evidence grounds each claim in external research, industry reporting, and practitioner experience. Entries intentionally include both support and tension.

### Evidence for Claim 1 — Execution is no longer the dominant constraint
**Support**
- Decades of software engineering research (Brooks, DeMarco, McConnell) show planning, coordination, and rework dominate timelines more than coding itself.
- Stack Overflow surveys report developers' primary friction as documentation, context, and understanding—not writing code.
- McKinsey and internal field studies show AI accelerates bounded coding tasks but exposes downstream bottlenecks in framing and verification.

**Challenges**
- Randomized field trials with expert developers in mature codebases show slowdowns due to verification tax and context mismatch.

**Q1 2026 additions**
- Continued maturation of AI coding tools (Claude Code GA, Cursor multi‑file editing, Windsurf, Copilot Workspace) further compresses execution cost for bounded tasks. (Tier B — vendor releases with disclosed capabilities.)
- SWE‑bench Verified leaderboard results for Q1 2026 models show continued improvement on well‑specified issues, reinforcing that execution capability is advancing while specification quality remains the limiting factor. (Tier A — benchmark with methods.)

**Interpretation**
Execution speed amplifies non-execution bottlenecks; it does not eliminate them.

---

### Evidence for Claim 2 — Architecture becomes ontological
**Support**
- Ontology-oriented system design (e.g., Palantir Foundry) collapses integration complexity by centralizing meaning, not wiring.
- Industry guidance (McKinsey, SAP, Salesforce) emphasizes shared ontologies as prerequisites for reliable AI agents.
- AI-first architecture discourse converges on knowledge graphs, schemas, and domain models as structural foundations.

**Challenges**
- Over-formalization risks rigidity and cultural resistance.

**Q1 2026 additions**
- Model Context Protocol (MCP) — Anthropic — 2024–2026 — open specification for agent‑tool interfaces. Defines tools, resources, and capabilities as semantic contracts. Adoption growing across agent frameworks. (Tier B — open spec with disclosed design.)
- Agent frameworks (LangChain, CrewAI, Anthropic SDK) universally require explicit tool/resource schemas. Agents without shared ontological contracts with their environment fail reliably. (Tier C — practitioner convergence, multiple independent sources.)

**Interpretation**
Architecture shifts toward explicit world-models that humans and machines share.

---

### Evidence for Claim 3 — AI punishes vague thinking
**Support**
- Practitioner reports show underspecified prompts yield plausible but incorrect artifacts at scale.
- Teams adopting AI successfully increase upfront specification detail and acceptance criteria.
- Emerging tools explicitly block execution until requirements and designs are articulated.

**Challenges**
- Short-term gains persist for narrowly scoped, well-understood tasks.

**Q1 2026 additions**
- Instruction files (CLAUDE.md, .cursorrules, .windsurfrules) became standard across AI coding tools. Their existence is practitioner‑level evidence: teams that codify context and constraints report better outcomes. (Tier C — multiple independent practitioner sources.)
- SWE‑bench Verified: specification quality remains the dominant predictor of solve rates even as model capability improves. (Tier A — benchmark with methods.)

**Interpretation**
AI exposes ambiguity faster than humans; clarity becomes a first-class skill.

---

### Evidence for Claim 4 — Authority shifts toward harness authorship
**Support**
- Research and industry commentary describe developer roles moving from coding to orchestration and supervision.
- Case studies show individuals framing problems and validation criteria wield disproportionate influence over outcomes.
- Outcome-based accountability increasingly supersedes activity metrics.

**Challenges**
- Informal power concentration and unclear arbitration mechanisms.

**Q1 2026 additions**
- Anthropic's "Building Effective Agents" documentation and Agent SDK patterns explicitly position the plan/spec author as the primary decision‑maker in agentic workflows. (Tier B — vendor with disclosed architecture.)
- Claude Code planning mode, Devin task decomposition, and Copilot Workspace all structurally separate intent definition from execution. Authority flows to whoever defines the plan and acceptance criteria. (Tier B — vendor convergence across multiple independent implementations.)

**Interpretation**
Authority follows those who define constraints, harnesses, and success conditions.

---

### Evidence for Claim 5a — Roles converge upward (greenfield / small teams)
**Support**
- Brynjolfsson et al. (NBER/QJE): AI tools compress skill differentials and enable faster upward mobility—most pronounced in smaller, less hierarchical settings.
- Surveys indicate dissolving role boundaries and increased generalist behavior among developers.
- LinkedIn data (Aneesh Raman): career "lattices" replacing "ladders"; generalist agility rising in value.
- Practitioner reports from startups and small product teams describe broadening role scopes post‑AI adoption.

**Challenges**
- Survivorship bias: visible small‑team successes may not represent the full distribution.
- Selection effect: generalists may self‑select into small teams rather than being created by AI.

**Interpretation**
In fluid, small‑team contexts, functions collapse faster than roles; individuals migrate upward in abstraction.

---

### Evidence for Claim 5b — Roles bifurcate (large enterprise / regulated)
**Support**
- ADP payroll data: routine cognitive tasks declining faster than manual ones, with effects concentrated in larger organizations.
- Stanford "Canaries in the Coal Mine" (Brynjolfsson et al., 2025): specific task categories declining while orchestration roles grow—but growth concentrated at senior levels.
- Reports of reduced junior developer hiring at large tech companies (Q4 2025–Q1 2026). (Tier C — journalism and job market analysis.)
- "Broken bottom rung" concern: if AI handles entry‑level tasks, the pipeline producing senior generalists may narrow.

**Challenges**
- NY Fed research (2025): aggregate employment stable; macro data does not yet show bifurcation.
- MIT Sloan analysis: AI effects are gradual, task‑specific, and often complementary; cautions against deterministic role‑elimination narratives.
- Some enterprises report *increased* junior hiring for AI‑augmented roles (data labeling, prompt engineering, validation).

**Interpretation**
In large, structured organizations, the evidence is genuinely mixed. Bifurcation is plausible but not yet confirmed at Tier A level. Track carefully.

---

### Evidence for Claim 6 — Safe autonomy requires seasoned intent and validation
**Support**
- High error and vulnerability rates in AI-generated code without strong validation.
- Best practices converge on phase-bounded autonomy with explicit tests and human review.
- Human-in-the-loop governance remains standard for high-stakes systems.

**Challenges**
- Tooling and process maturity uneven across organizations.

**Q1 2026 additions**
- Multiple independent vendors converged on phase‑bounded autonomy: Claude Code (plan mode + human checkpoints), Devin (task decomposition with verification), Copilot Workspace (spec → plan → implement → validate). (Tier B — vendor architecture convergence.)
- Anthropic Agent SDK and "Building Effective Agents" guidance explicitly recommends human‑in‑the‑loop checkpoints and bounded autonomy scopes. (Tier B — vendor with disclosed methods.)

**Interpretation**
Autonomy applies to execution; intent and verification remain human responsibilities.

</details>

---

<details>
<summary><strong>🔗 Sources & References</strong> — Comprehensive linked bibliography</summary>

## Sources and references (comprehensive, linked index)

**Last refreshed:** 2026-03-30
**Format:** *Title — Author/Org — Venue — Date — Link(s)*  

### Inclusion rules (so “comprehensive” doesn’t become “everything on the internet”)
- Prefer **Tier A** (peer-reviewed / preprint w/ methods + data; benchmark repos; official survey datasets).
- Include **Tier B** (industry research with disclosed methods).
- Include **Tier C** (reputable secondary synthesis / practitioner writeups) only when they add clarity, critiques, or field context.
- Maintain an explicit **best counter-evidence** set for each claim.

### Evidence quality rubric (operational)
- **Tier A:** peer-reviewed or strong preprint with methods + data; official datasets/benchmarks.
- **Tier B:** vendor research with methods; reputable org reports.
- **Tier C:** high-quality journalism or practitioner essays with concrete examples.
- **Tier D:** anecdotes (useful prompts for hypotheses; never decisive).

---

## Claim-to-source matrix (expanded)

This is the “wiring diagram” that keeps the doctrine honest.

### Claim 1 — Execution is no longer the dominant constraint
**Support (Tier A/B)**
- *The Mythical Man-Month* — F.P. Brooks — Addison-Wesley — 1975.
  <br>**Summary:** Foundational software engineering text arguing that adding developers to late projects makes them later; demonstrates that communication and coordination—not coding—dominate software effort.

- *Code Complete* — Steve McConnell — Microsoft Press — 1993.
  <br>**Summary:** Comprehensive guide to software construction showing that design decisions, requirements clarity, and defect prevention matter more than raw coding speed.

- *AI | 2025 Stack Overflow Developer Survey* — Stack Overflow — 2025 — https://survey.stackoverflow.co/2025/ai/
  <br>**Summary:** Annual survey of 65,000+ developers; reveals that understanding existing code, documentation, and system context remain primary friction points—not writing code.

- *Developer Experience Report 2025* — Atlassian — 2025-07-09 — https://www.atlassian.com/blog/developer/developer-experience-report-2025
  <br>**Summary:** Industry report on developer productivity; finds that context switching, unclear requirements, and collaboration overhead are top productivity drains.

- *The State of Developer Experience in 2025* (PDF) — Atlassian — 2025 — https://dam-cdn.atl.orangelogic.com/AssetLink/85sxf1ilee4qpav1236gkfke5wmm33gj.pdf
  <br>**Summary:** Full research PDF companion to above; includes quantitative data on where developer time actually goes.

- *The Impact of AI on Developer Productivity: Evidence from GitHub Copilot* — Microsoft Research — 2023 — https://www.microsoft.com/en-us/research/publication/the-impact-of-ai-on-developer-productivity-evidence-from-github-copilot/
  <br>**Summary:** Randomized controlled trial showing 55% faster task completion with Copilot on bounded coding tasks—but measuring isolated coding, not full development lifecycle.

- *Measuring the Impact of Early-2025 AI on Experienced Open-Source Developer Productivity* — Becker, Rush, Barnes, Rein — METR — 2025-07-10 — https://metr.org/blog/2025-07-10-early-2025-ai-experienced-os-dev-study/
  <br>**Summary:** Rigorous RCT finding that experienced developers were actually *slower* with AI tools in mature codebases—verification overhead and context mismatch negated speed gains.

- Same study (arXiv) — 2025 — https://arxiv.org/abs/2507.09089
  <br>**Summary:** Academic preprint of the METR study with full methodology and statistical analysis.

**Best counter-evidence (Tier A)**
- METR RCT above: experienced devs in mature repos were **slower** with early‑2025 AI tools (verification + context tax).
  <br>**Why included:** Directly challenges the claim by showing execution bottlenecks can *increase* with AI when verification costs dominate. The doctrine's response: this confirms that non-execution work (verification, context) is the actual constraint.

---

### Claim 2 — Architecture becomes ontological, not just structural
**Support (Tier B)**
- *Overview • Ontology* — Palantir Foundry Docs — https://www.palantir.com/docs/foundry/ontology/overview
  <br>**Summary:** Describes Palantir's ontology layer—a semantic framework where business objects, relationships, and actions are defined once and reused across all applications, collapsing integration complexity.

- *Ontologies • Overview* — Palantir Foundry Docs — https://www.palantir.com/docs/foundry/ontologies/ontologies-overview
  <br>**Summary:** Technical documentation on building ontologies; shows how shared meaning (not shared pipelines) enables coordination at scale.

- *Ontology SDK (OSDK) • Overview* — Palantir Foundry Docs — https://www.palantir.com/docs/foundry/ontology-sdk/overview
  <br>**Summary:** Developer SDK for ontology-driven applications; demonstrates how code generation from ontological definitions accelerates AI agent development.

**Challenges / cautions (Tier C)**
- General critique theme: over-formalization → documentation drag + rigidity. (See spec-driven critique set below.)
  <br>**Why included:** Ontologies can calcify into heavyweight enterprise models that slow adaptation; the doctrine acknowledges this tension.

---

### Claim 3 — AI punishes vague thinking faster than humans do
**Support (Tier A/B/C)**
- *SWE-bench* (benchmark repo) — SWE-bench authors — ICLR 2024 — https://github.com/swe-bench/SWE-bench
  <br>**Summary:** Benchmark for evaluating AI on real GitHub issues; success rates correlate strongly with issue specificity—vague issues yield low solve rates even with capable models.

- *The Impact of AI on Developer Productivity: Evidence from GitHub Copilot* — Microsoft Research — 2023 — https://www.microsoft.com/en-us/research/publication/the-impact-of-ai-on-developer-productivity-evidence-from-github-copilot/
  <br>**Summary:** Shows AI excels on well-specified, bounded tasks; implicitly supports the claim that unclear requirements limit AI effectiveness.

- *AI writes code faster. Your job is still to prove it works.* — Addy Osmani — 2026-01-07 — https://addyosmani.com/blog/code-review-ai/
  <br>**Summary:** Chrome DevRel lead argues that AI shifts developer work toward review and verification; poor specs create "plausible garbage" at scale.

- *Developers remain willing but reluctant to use AI…* — Stack Overflow Blog — 2025-12-29 — https://stackoverflow.blog/2025/12/29/developers-remain-willing-but-reluctant-to-use-ai-the-2025-developer-survey-results-are-here/
  <br>**Summary:** Survey analysis showing developers trust AI for boilerplate but distrust it for complex logic—quality depends on task clarity.

**Best counter-evidence (Tier A)**
- The Copilot experiment shows large speedups on bounded tasks; i.e., vagueness is not always punished in toy or greenfield contexts.
  <br>**Why included:** In well-defined, isolated coding exercises, vagueness may not hurt. The doctrine's scope is production systems where ambiguity compounds.

---

### Claim 4 — Authority shifts toward harness authorship and outcomes
**Support (Tier B/C)**
- *Spec-driven development: Unpacking one of 2025's key new AI-assisted engineering practices* — Thoughtworks — 2025 — https://www.thoughtworks.com/insights/blog/agile-engineering-practices/spec-driven-development-unpacking-2025-new-engineering-practices
  <br>**Summary:** Thoughtworks analysis of emerging "spec-driven development" pattern where upfront specification becomes the primary artifact; positions spec authors as key decision-makers.

- *Understanding Spec-Driven-Development: Kiro, spec-kit, and Tessl* — Martin Fowler / Thoughtworks — 2025 — https://martinfowler.com/articles/exploring-gen-ai/sdd-3-tools.html
  <br>**Summary:** Martin Fowler's exploration of spec-driven tools; shows how those who define specs and validation criteria shape what gets built.

- *AI writes code faster… prove it works* — Addy Osmani — 2026-01-07 — https://addyosmani.com/blog/code-review-ai/
  <br>**Summary:** Argues that review and validation—not coding—become the valued activities; authority flows to those who define correctness criteria.

**Challenges (Tier C)**
- Spec-driven workflows can re-centralize power into "spec priests," and can create a false sense of correctness without strong tests.
  <br>**Why included:** Risk that "harness authorship" becomes gatekeeping without accountability; doctrine must guard against this failure mode.

---

### Claim 5a — Roles converge upward (greenfield / small teams)
**Support (Tier A/B/C)**
- *Generative AI at Work* — Brynjolfsson, Li, Raymond — NBER WP 31161 — 2023 (rev. 2023-11) — https://www.nber.org/papers/w31161
  <br>**Summary:** NBER study of 5,000+ customer service agents; AI tools boosted productivity most for novice workers, compressing skill differentials and enabling faster upward mobility. Effect strongest in less hierarchical settings.

- Journal version — QJE — 2024/2025 — https://academic.oup.com/qje/article/140/2/889/7990658
  <br>**Summary:** Peer-reviewed version in Quarterly Journal of Economics; adds rigor and replication to the NBER findings.

- *LinkedIn's Aneesh Raman says the career ladder is disappearing…* — Fast Company — 2025 — https://www.fastcompany.com/91375183/linkedin-aneesh-raman-ai-career-ladders
  <br>**Summary:** LinkedIn's VP of Workforce Development argues traditional career ladders are becoming "lattices"—generalist agility matters more than specialist depth.

**Best counter-evidence (Tier A/B)**
- *How artificial intelligence impacts the US labor market* — MIT Sloan — 2025 — https://mitsloan.mit.edu/ideas-made-to-matter/how-artificial-intelligence-impacts-us-labor-market
  <br>**Summary:** MIT analysis showing AI effects are gradual, task-specific, and often complementary; convergence may be slower than practitioner narratives suggest.
  <br>**Why included:** Tempers the velocity of the convergence claim even in contexts where directionality is correct.

---

### Claim 5b — Roles bifurcate (large enterprise / regulated)
**Support (Tier A/B/C)**
- *Canaries in the Coal Mine? Six Facts…* — Brynjolfsson et al. — Stanford Digital Economy Lab — 2025-08 — https://digitaleconomy.stanford.edu/wp-content/uploads/2025/08/Canaries_BrynjolfssonChandarChen.pdf
  <br>**Summary:** Stanford research tracking early labor market signals; finds specific task categories declining while orchestration roles grow—but growth concentrated at senior levels in larger organizations.

- *Yes, AI is affecting employment. Here's the data.* — ADP Research — 2025 — https://www.adpresearch.com/yes-ai-is-affecting-employment-heres-the-data/
  <br>**Summary:** ADP payroll data analysis showing shifts in job composition; routine cognitive tasks declining faster than manual ones, with larger effects in bigger firms.

**Best counter-evidence (Tier A/B)**
- *AI not affecting job market much so far, New York Fed says* — Reuters — 2025-09-04 — (use as macro counterweight when discussing job-loss certainty).
  <br>**Why included:** Macro labor data shows aggregate employment stable; warns against overstating bifurcation velocity.

- *How artificial intelligence impacts the US labor market* — MIT Sloan — 2025 — https://mitsloan.mit.edu/ideas-made-to-matter/how-artificial-intelligence-impacts-us-labor-market
  <br>**Summary:** MIT analysis showing AI effects are gradual, task-specific, and often complementary; cautions against deterministic bifurcation narratives.

---

### Claim 6 — Safe autonomy requires seasoned intent and explicit validation
**Support (Tier A/B/C)**
- *2025 GenAI Code Security Report* — Veracode — 2025 — https://www.veracode.com/resources/analyst-reports/2025-genai-code-security-report/
  <br>**Summary:** Analysis of AI-generated code security; finds 48% of AI-assisted development tasks introduce vulnerabilities without strong validation gates.

- *OWASP Top 10:2025* — OWASP — 2025 — https://owasp.org/Top10/2025/
  <br>**Summary:** Updated web security risks; increasingly includes AI-specific attack surfaces and emphasizes validation as the primary defense.

- *SWE-bench* — benchmark repo — https://github.com/swe-bench/SWE-bench
  <br>**Summary:** AI coding benchmark; shows that autonomous success depends heavily on problem specification quality and test coverage.

- *AI writes code faster… prove it works* — Addy Osmani — 2026-01-07 — https://addyosmani.com/blog/code-review-ai/
  <br>**Summary:** Practical guide arguing AI output requires more rigorous review, not less—speed without validation produces technical debt.

**Operational cautionary cases (Tier C)**
- *Klarna is reassigning engineers and marketers to customer support after its AI bet went too far* — Business Insider — 2025 — (quality regression case study).
  <br>**Why included:** Real-world example of autonomy without adequate validation leading to service quality regression; demonstrates consequences of insufficient human oversight.

---

## Spec-driven / harness-based development: support + critique set

**Support / framing**
- Thoughtworks SDD overview — https://www.thoughtworks.com/insights/blog/agile-engineering-practices/spec-driven-development-unpacking-2025-new-engineering-practices
  <br>**Summary:** Defines spec-driven development as the practice of writing detailed specifications *before* AI generates code; positions it as a maturation of AI-assisted workflows.

- Martin Fowler (tools + framing) — https://martinfowler.com/articles/exploring-gen-ai/sdd-3-tools.html
  <br>**Summary:** Reviews emerging spec-driven tools (Kiro, spec-kit, Tessl); provides balanced analysis of benefits and limitations in practice.

**Critiques / counterweights**
- *Putting Spec Kit Through Its Paces…* — Scott Logic — 2025-11-26 — https://blog.scottlogic.com/2025/11/26/putting-spec-kit-through-its-paces-radical-idea-or-reinvented-waterfall.html
  <br>**Summary:** Critical evaluation finding that spec-kit reintroduces waterfall rigidity; specs became documentation debt rather than living guidance.

- *Spec-Driven Development: The Waterfall Strikes Back* — marmelab — 2025-11-12 — https://marmelab.com/blog/2025/11/12/spec-driven-development-waterfall-strikes-back.html
  <br>**Summary:** Argues that over-specified upfront workflows recreate waterfall's worst pathologies—slow iteration, delayed feedback, false certainty.

**Why keep both?**
Because "specs as guardrails" is directionally right, but "specs as salvation" is how you reinvent a slow, smug waterfall.

---

## Organizational structure analogs (for the "Valve-like" model)
- *Valve Corporation: Strategy tipping points and thresholds* — Teppo Felin — Journal of Organization Design — 2015 — https://www.jorgdesign.net/article/view/20157
  <br>**Summary:** Academic study of Valve's flat, project-based structure; analyzes how peer-based authority and self-selection can work at scale.

- PDF — https://www.jorgdesign.net/article/download/20157/18615/48160
  <br>**Summary:** Full academic paper with organizational theory framework for analyzing emergent authority structures.

- *Handbook for New Employees* (Valve) — 2012 — https://www.valvesoftware.com/company/Valve_Handbook.pdf
  <br>**Summary:** Primary source document showing how Valve operationalizes flat hierarchy, project self-selection, and peer-based accountability.

---

## Additional sources referenced elsewhere in the doctrine (linked)
- Stack Overflow blog post (survey synthesis) — https://stackoverflow.blog/2025/12/29/developers-remain-willing-but-reluctant-to-use-ai-the-2025-developer-survey-results-are-here/
  <br>**Summary:** Editorial analysis of the 2025 developer survey; highlights the trust gap between AI capability and developer confidence.

- Veracode report press coverage (announcement) — https://www.businesswire.com/news/home/20250730694951/en/AI-Generated-Code-Poses-Major-Security-Risks-in-Nearly-Half-of-All-Development-Tasks-Veracode-Research-Reveals
  <br>**Summary:** Press release for the Veracode security study; accessible summary of the 48% vulnerability finding in AI-assisted code.

- The New Stack (review bottleneck discussion) — https://thenewstack.io/is-ai-creating-a-new-code-review-bottleneck-for-senior-engineers/
  <br>**Summary:** Industry reporting on emerging "review bottleneck" where senior engineers spend disproportionate time validating AI output from junior contributors.

---

## Upgrades recommended (implemented in this revision)

### 1) Explicit “best counter-evidence” per claim
Every claim now has at least one strong opposing datapoint or cautionary result.

### 2) Linked bibliography
Every major source now includes a direct link for exploration.

### 3) Spec-driven discourse treated as a contested space
We preserve both pro and anti sources instead of laundering a trend into doctrine.

</details>

---

<details>
<summary><strong>⚖️ Status Rules</strong> — How claims change state</summary>

## Status rules (how claims change state)

Claim statuses are not vibes. They follow explicit thresholds.

### Status definitions
- **Proposed:** articulated but not yet anchored in Tier A/B evidence.
- **Active:** plausible and internally observed; evidence mixed or incomplete.
- **Emerging:** early external evidence supports directionality; counter-evidence exists.
- **Supported:** multiple independent sources support; contradictions are bounded.
- **Strongly supported:** supported + repeatedly replicated across contexts; counter-evidence is edge‑case or tool‑generation specific.
- **Contentious:** high-quality evidence exists on both sides; mechanism unclear.
- **Refuted (for now):** best available Tier A/B evidence contradicts the claim in the relevant scope.
- **Retired:** claim is no longer useful or has been subsumed by a more precise claim.

### Promotion thresholds
A claim may be promoted one level when ALL are true:
- At least **2 independent Tier A** sources OR **1 Tier A + 2 Tier B** sources directly support the claim's mechanism.
- At least **1 credible counter-source** has been reviewed and the doctrine captures why it does not invalidate the claim's scope.
- The claim has at least **one operational metric** that can be measured internally.

### Demotion / refutation thresholds
A claim should be demoted when ANY are true:
- A **Tier A** result contradicts the claim *in the doctrine's stated scope* and cannot be re-scoped without gutting the claim.
- Internal measures consistently move opposite the prediction for **2 consecutive quarters**.
- The claim cannot be translated into observable predictions (non-falsifiable).

### Split rule
If both support and counter-evidence remain strong, do not average them into mush.
Instead, **split the claim** by context (greenfield vs mature codebase; bounded tasks vs system-level change; novice vs expert).

</details>

---

<details>
<summary><strong>📊 Metrics & Instrumentation</strong> — Measurable signals per claim</summary>

## Metrics and instrumentation appendix (internal auditability)

Each claim must map to at least one measurable signal. These are suggested metrics; pick the ones you can actually instrument without bureaucratic theater.

### Claim 1 metrics (execution vs framing)
- **Framing ratio:** (time in intent/spec/design) ÷ (time in implementation).
- **Rework taxonomy:** % rework due to *misalignment/spec ambiguity* vs *technical defects*.
- **Review burden:** median review time per PR; % of review comments that are semantic vs syntactic.

### Claim 2 metrics (ontological architecture)
- **Semantic disagreement rate:** number of disputes about definitions/invariants per sprint.
- **Schema churn:** changes per quarter to canonical vocabularies/schemas/event names.
- **Interface stability:** breaking-change frequency for key APIs/events.

### Claim 3 metrics (vagueness penalty)
- **Spec completeness score:** checklist-based completeness on intent docs (acceptance criteria present, invariants listed, negative cases defined).
- **AI correction rate:** % of AI-generated artifacts requiring material correction.
- **Hallucination incidence:** tracked by category (wrong API usage, invented fields, incorrect assumptions).

### Claim 4 metrics (authority shift)
- **Harness authorship concentration:** distribution of who authors/maintains harnesses (Gini coefficient optional).
- **Outcome ownership clarity:** % of workstreams with explicit owner, success metric, and validation plan.
- **Arbitration load:** frequency and type of conflicts requiring escalation.

### Claim 5a metrics (role convergence — greenfield / small teams)
- **Worktype breadth per person:** count of domains touched per quarter (design, FE, BE, infra, data, ops) in teams <15 people.
- **Generalist hire ratio:** % of hires with cross‑domain expectations vs single‑domain in sub‑50‑person orgs.
- **Time‑to‑impact:** onboarding slope for new generalist contributors in small‑team settings.

### Claim 5b metrics (role bifurcation — enterprise)
- **Junior‑to‑senior hiring ratio:** tracked per quarter in orgs >500 employees.
- **Function displacement index:** tasks automated or eliminated vs tasks created, segmented by seniority level.
- **"Broken bottom rung" indicator:** time‑to‑senior for new hires over time; watch for pipeline narrowing.
- **Wage distribution:** compression vs polarization in engineering compensation bands.

### Claim 6 metrics (safe autonomy)
- **Autonomous run success rate:** % runs that pass validation without human intervention.
- **Defect escape rate:** production issues attributable to AI-generated changes.
- **Security gate catches:** vuln findings per AI-generated change-set vs human-authored baseline.

</details>

---

<details>
<summary><strong>📡 Telecom Translation Layer</strong> — Domain-specific mapping</summary>

## Telecom translation layer (how this doctrine maps to our domain)

This section makes the doctrine legible in telecommunications, where "meaning" is operationally encoded as products, entitlements, network states, and support responsibilities.

### What "ontology" means in telecom
- **Product catalog ontology:** products, plan variants, promotions, cohorts, markets, merchants/providers.
- **Entitlement ontology:** what the subscriber is allowed to do/receive (speed tier, voice features, add-ons).
- **Network/provisioning ontology:** service state machines, circuit/device identities, provisioning events.
- **Billing ontology:** charges, invoices, delinquency rules, proration, payment method constraints.
- **Support ontology:** routing rules, responsibility boundaries (internal vs provider), escalation contracts.

### Where harnesses naturally live in telecom
- **Event-driven workflows:** provisioning pipelines, order fulfillment, porting, incident response.
- **Contractual processes:** SLA enforcement, handoffs, compliance requirements.
- **Multi-party coordination:** marketplace/provider interplay, responsibility boundaries, audit trails.

### Telecom-specific "vagueness penalties" (Claim 3)
- Ambiguous eligibility rules → wrong product exposure.
- Underspecified state transitions → stuck provisioning and ghost entitlements.
- Loose responsibility definitions → support ping-pong.

### Telecom-specific validation harnesses (Claim 6)
- Deterministic tests for billing math (proration, delinquency, autopay logic).
- Contract tests for event schemas and versioning.
- State-machine property tests for provisioning transitions.
- Synthetic monitoring tied to subscriber experience KPIs (activation success, latency, call quality, outage impacts).

</details>

---

<details>
<summary><strong>🔍 Skeptic's Appendix</strong> — Best-faith challenges and falsification criteria</summary>

## Skeptic's appendix (best-faith challenges)

This section enumerates the strongest credible objections to each claim and specifies what evidence would falsify or materially weaken the doctrine. The purpose is *pressure-testing*, not rebuttal theater.

### Skepticism toward Claim 1 — "Execution is no longer the dominant constraint"
**Objection:** In many real organizations, execution is still slow due to legacy systems, regulatory drag, and understaffing—not thinking quality.

**What would falsify the claim:**
- Tier A evidence showing sustained productivity gains end-to-end (not just coding tasks) from AI in mature, regulated systems *without* increased review/rework cost.
- Internal metrics showing implementation time dominating framing and rework for multiple quarters.

---

### Skepticism toward Claim 2 — "Architecture becomes ontological"
**Objection:** Ontologies overfit reality, calcify prematurely, and recreate heavyweight enterprise modeling failures of the past.

**What would falsify the claim:**
- Evidence that teams with minimal shared semantics outperform ontology-driven teams at scale.
- Repeated failures where explicit ontologies slow adaptation more than they reduce coordination cost.

---

### Skepticism toward Claim 3 — "AI punishes vague thinking faster"
**Objection:** Skilled practitioners can iterate their way to clarity cheaply; vagueness is survivable with fast feedback loops.

**What would falsify the claim:**
- High-quality evidence that loosely specified AI-driven workflows consistently converge faster than spec-driven ones in complex domains.
- Internal data showing no correlation between intent clarity and AI correction rate.

---

### Skepticism toward Claim 4 — "Authority shifts toward harness authorship"
**Objection:** Power still accrues to people managers and budget holders; harness authorship is a technical detail, not authority.

**What would falsify the claim:**
- Organizational case studies where harness authorship has little or no influence on prioritization, outcomes, or decision rights.
- Persistent misalignment between harness definitions and shipped outcomes.

---

### Skepticism toward Claim 5a — "Roles converge upward (greenfield / small teams)"
**Objection:** Convergence in small teams is survivorship bias — we see the successes, not the failures. Generalists self‑select into small teams; AI doesn't create them.

**What would falsify the claim:**
- Evidence that small teams with AI‑augmented specialists consistently outperform generalist teams.
- Longitudinal data showing no increase in role breadth in startup/small‑team contexts post‑AI adoption.

---

### Skepticism toward Claim 5b — "Roles bifurcate (large enterprise / regulated)"
**Objection:** Bifurcation is an overreaction to short‑term hiring freezes. Enterprises will adapt by creating new mid‑level roles (AI trainers, prompt engineers, validation specialists) that fill the middle.

**What would falsify the claim:**
- Longitudinal enterprise labor data showing stable or growing mid‑level execution roles despite AI adoption.
- Evidence that enterprises are creating *new* mid‑level roles at a rate that offsets the decline of existing ones.
- Internal evidence that junior‑to‑senior pipelines remain healthy in AI‑heavy enterprise teams.

---

### Skepticism toward Claim 6 — "Safe autonomy requires seasoned intent and validation"
**Objection:** Improved models and self-correcting agents will reduce the need for heavy upfront intent and human validation.

**What would falsify the claim:**
- Benchmarks showing agents achieving low defect and security rates in open-ended tasks without strong harnesses.
- Internal deployments where free-form autonomy outperforms phase-bounded autonomy on reliability and safety metrics.

---

**Doctrine integrity rule:**
If multiple skeptic falsification conditions are met, the corresponding claim must be demoted, split, or retired—even if doing so is uncomfortable.

</details>

---

<!-- pagebreak -->

## Review cadence
- **Quarterly:** re-evaluate each claim status against new evidence
- **Annually:** revise the thesis if multiple claims flip or collapse
- **Ad hoc:** annotate disruptive evidence (new benchmarks, RCTs, major failures)

<details>
<summary><strong>Quarterly review checklist</strong></summary>

1. For each claim: review new Tier A/B sources published since last review
2. For each claim: check promotion/demotion thresholds against updated evidence
3. For each claim: note any internal metric observations (even qualitative)
4. Check Split Rule: does any claim have strong evidence on both sides that warrants splitting by context?
5. Update evidence registry and sources with new entries; classify each by tier
6. Update "Last refreshed" date in Sources & References
7. Add "Q1/Q2/Q3/Q4 YYYY observations" subsection under each claim
8. Write changelog entry with claim status changes, evidence additions, and structural changes
9. Bump version per semantic versioning rules (MAJOR for claim changes, MINOR for evidence/status, PATCH for formatting)
10. Update Claims Dashboard table (statuses, "Last Changed" column)
11. Update metadata `current_revision_date` and `review_history`

</details>

---

<details>
<summary><strong>📜 Changelog</strong></summary>

## Changelog (historical record)

This section records meaningful changes to the doctrine over time. Entries should be concise and factual.

### v1.0.0 — 2026-03-30 (Q1 quarterly review)
- **MAJOR: Claim 5 split into 5a and 5b** per the Split Rule. Original "Contentious" claim separated by context:
  - Claim 5a (greenfield / small teams → convergence): Emerging.
  - Claim 5b (large enterprise / regulated → bifurcation): Proposed.
- **Claim 6 promoted:** Early validation → Emerging. Vendor convergence on phase‑bounded autonomy (Claude Code, Devin, Copilot Workspace) plus unrebutted Veracode security data met promotion threshold.
- Claims 1–4 held at current statuses; Q1 2026 observation notes added to each.
- Evidence registry refreshed: added 8 new source entries across 6 claims. Sources last‑refreshed date updated.
- Claim 5 evidence, metrics, and skeptic's appendix entries split into 5a and 5b.
- Added "Last Changed" column to Claims Dashboard.
- Added `review_history` field to metadata.
- Added quarterly review checklist to Review Cadence section.

### v0.1.0 — 2026-01-09
- Initial formalization of doctrine, claims, evidence registry, skeptic's appendix, and metrics framework.
- Added archival metadata, author context, and stewardship obligations.
- Established Arbuckle as a reference implementation and falsification surface.

</details>

---

## Closing principle

> [!TIP]
> Infinite capability without constrained intent does not produce success.
> It produces noise at scale.

This doctrine exists to constrain thinking *just enough* to make progress real.

