/**
 * Extracts structured data from doctrine-1.md and outputs clean JSON-LD.
 * 
 * Strategy:
 * - Evidence comes from "Sources and references" (formal citations with URLs)
 * - Evidence Registry provides narrative context but its bullet points 
 *   are interpretive summaries, not primary sources — we skip those
 * - Skepticism, metrics from their respective sections
 */
import fs from "fs";

const raw = fs.readFileSync("doctrine-1.md", "utf-8");

// ─── Types ───
interface EvidenceEntry {
  title: string;
  author?: string;
  url?: string;
  tier?: "A" | "B" | "C" | "D";
  summary?: string;
  type: "support" | "counter";
}

// ─── Evidence from "Sources and references" section only ───
function extractEvidence(): Map<string, EvidenceEntry[]> {
  const result = new Map<string, EvidenceEntry[]>();

  const sourcesMatch = raw.match(
    /## Sources and references.*?\n([\s\S]*?)(?=<\/details>)/
  );
  if (!sourcesMatch) return result;

  const sections = sourcesMatch[1].split(/(?=### Claim \d)/);

  for (const section of sections) {
    const headerMatch = section.match(/### Claim (\d+\w?)\b/i);
    if (!headerMatch) continue;

    const claimKey = headerMatch[1].toLowerCase();
    const items: EvidenceEntry[] = [];
    const seenTitles = new Set<string>();
    let currentType: "support" | "counter" = "support";

    const lines = section.split("\n");
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];

      // Type switching
      if (/\*\*Support/i.test(line) || /\*\*Tier A/i.test(line) || /\*\*Q1/i.test(line) || /\*\*framing/i.test(line)) {
        currentType = "support";
        continue;
      }
      if (/\*\*Challenge/i.test(line) || /\*\*Best counter/i.test(line) || /\*\*Critiques/i.test(line) || /\*\*cautions/i.test(line) || /\*\*Operational cautionary/i.test(line)) {
        currentType = "counter";
        continue;
      }

      // Match italic entry: - *Title* — Author — Date — URL
      const italicMatch = line.match(/^- \*(.+?)\*\s*(?:—\s*(.+?))?$/);
      
      // Also handle non-italic counter-evidence entries
      if (!italicMatch) {
        // Only capture plain bullets when we're in counter-evidence mode
        if (currentType === "counter") {
          const plainMatch = line.match(/^- (.{15,})$/);
          if (plainMatch) {
            const text = plainMatch[1].trim();
            // Skip section headers and tier definitions
            if (text.startsWith("**") && text.endsWith("**")) continue;
            if (/^\*\*Tier [ABCD]:\*\*/.test(text)) continue;
            // skip if it's just a theme reference, not a real entry
            if (text.length < 20) continue;
            
            const cleanTitle = text.replace(/\*\*/g, "").replace(/\*/g, "");
            const titleKey = cleanTitle.toLowerCase().replace(/[^a-z0-9]/g, "");
            if (seenTitles.has(titleKey)) continue;
            seenTitles.add(titleKey);

            // Extract URL if embedded
            const embeddedUrl = text.match(/(https?:\/\/[^\s]+)/);
            
            let summary: string | undefined;
            for (let j = i + 1; j <= i + 4 && j < lines.length; j++) {
              const next = lines[j]?.trim();
              if (next?.startsWith("<br>**Why included:**")) {
                summary = next.replace(/<br>\*\*Why included:\*\*\s*/, "").replace(/\*/g, "");
                break;
              }
              if (next?.startsWith("<br>**Summary:**")) {
                summary = next.replace(/<br>\*\*Summary:\*\*\s*/, "").replace(/\*/g, "");
                break;
              }
            }

            items.push({
              title: cleanTitle.replace(/(https?:\/\/[^\s]+)/, "").trim(),
              url: embeddedUrl?.[1],
              summary,
              type: "counter",
            });
          }
        }
        continue;
      }

      const title = italicMatch[1].trim();
      const titleKey = title.toLowerCase().replace(/[^a-z0-9]/g, "");
      if (seenTitles.has(titleKey)) continue;
      seenTitles.add(titleKey);

      const rest = italicMatch[2] || "";
      
      // Extract URL from the rest string
      const urlMatch = rest.match(/(https?:\/\/[^\s]+)/);
      let url = urlMatch?.[1];
      
      // Parse author from everything before the URL (split by —)
      const beforeUrl = rest.replace(/(https?:\/\/[^\s]+)/, "").trim();
      const parts = beforeUrl.split(/\s*—\s*/).filter(Boolean);
      // Usually: Author — Date  or Author — Venue — Date
      const author = parts[0]?.trim() || undefined;

      // Look ahead for summary / why-included
      let summary: string | undefined;
      for (let j = i + 1; j <= i + 4 && j < lines.length; j++) {
        const next = lines[j]?.trim();
        if (next?.startsWith("<br>**Summary:**")) {
          summary = next.replace(/<br>\*\*Summary:\*\*\s*/, "").replace(/\*/g, "");
          break;
        }
        if (next?.startsWith("<br>**Why included:**")) {
          summary = next.replace(/<br>\*\*Why included:\*\*\s*/, "").replace(/\*/g, "");
          break;
        }
      }

      // Infer tier from section-level header
      let tier: "A" | "B" | "C" | "D" | undefined;
      // Check the section header for Tier info
      const sectionHeader = lines.slice(0, 5).join(" ");
      if (/Tier A\/B\b/i.test(sectionHeader)) tier = "A";
      else if (/Tier A\b/i.test(sectionHeader)) tier = "A";
      else if (/Tier B\/C\b/i.test(sectionHeader)) tier = "B";
      else if (/Tier B\b/i.test(sectionHeader)) tier = "B";
      else if (/Tier A\/B\/C\b/i.test(sectionHeader)) tier = "A";
      else if (/Tier C\b/i.test(sectionHeader)) tier = "C";
      
      // Check nearby context more specifically
      const nearContext = lines.slice(Math.max(0, i - 3), i + 1).join(" ");
      const nearTier = nearContext.match(/\(Tier ([ABCD])(?:\/[ABCD])?(?:\s*—[^)]+)?\)/i);
      if (nearTier) tier = nearTier[1].toUpperCase() as any;
      // Also check the entry's own parenthetical
      const inlineTier = rest.match(/Tier ([ABCD])\b/i);
      if (inlineTier) tier = inlineTier[1].toUpperCase() as any;

      items.push({ title, author, url, tier, summary, type: currentType });
    }

    result.set(claimKey, items);
  }

  // Also handle the "Spec-driven / harness-based development" section
  const specMatch = raw.match(
    /## Spec-driven \/ harness-based development.*?\n([\s\S]*?)(?=\n---\n|\n## )/
  );
  if (specMatch) {
    let currentType: "support" | "counter" = "support";
    const lines = specMatch[1].split("\n");
    const specItems: EvidenceEntry[] = [];
    
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      if (/\*\*Support/i.test(line) || /\*\*framing/i.test(line)) { currentType = "support"; continue; }
      if (/\*\*Critiques/i.test(line) || /\*\*counter/i.test(line)) { currentType = "counter"; continue; }

      const italicMatch = line.match(/^- \*(.+?)\*\s*(?:—\s*(.+?))?$/);
      if (!italicMatch) continue;

      const title = italicMatch[1].trim();
      const rest = italicMatch[2] || "";
      const urlMatch = rest.match(/(https?:\/\/[^\s]+)/);
      const url = urlMatch?.[1];
      const author = rest.replace(/(https?:\/\/[^\s]+)/, "").replace(/\s*—\s*$/, "").trim() || undefined;

      let summary: string | undefined;
      for (let j = i + 1; j <= i + 3 && j < lines.length; j++) {
        const next = lines[j]?.trim();
        if (next?.startsWith("<br>**Summary:**")) {
          summary = next.replace(/<br>\*\*Summary:\*\*\s*/, "").replace(/\*/g, "");
          break;
        }
      }

      specItems.push({ title, author, url, tier: "C", summary, type: currentType });
    }

    // Add spec items to claim 4 (harness authorship) if not already present
    const c4 = result.get("4") || [];
    const c4Titles = new Set(c4.map(e => e.title.toLowerCase().replace(/[^a-z0-9]/g, "")));
    for (const item of specItems) {
      if (!c4Titles.has(item.title.toLowerCase().replace(/[^a-z0-9]/g, ""))) {
        c4.push(item);
      }
    }
    result.set("4", c4);
  }

  return result;
}

// ─── Skepticism ───
function extractSkepticism(): Map<string, { objection: string; falsification: string[] }> {
  const result = new Map();
  const match = raw.match(/## Skeptic's appendix.*?\n([\s\S]*?)(?=<\/details>)/);
  if (!match) return result;

  const sections = match[1].split(/(?=### Skepticism toward Claim \d)/);
  for (const section of sections) {
    const header = section.match(/### Skepticism toward Claim (\d+\w?)\b/i);
    if (!header) continue;

    const objMatch = section.match(/\*\*Objection:\*\*\s*(.+)/);
    const falsifyMatch = section.match(/\*\*What would falsify the claim:\*\*\s*\n((?:- .+\n?)+)/);
    const falsification = falsifyMatch
      ? falsifyMatch[1].split("\n").filter(l => l.trim().startsWith("- ")).map(l => l.trim().replace(/^- /, ""))
      : [];

    result.set(header[1].toLowerCase(), {
      objection: objMatch?.[1]?.trim() || "",
      falsification,
    });
  }
  return result;
}

// ─── Metrics ───
function extractMetrics(): Map<string, { name: string; description: string }[]> {
  const result = new Map();
  const match = raw.match(/## Metrics and instrumentation.*?\n([\s\S]*?)(?=<\/details>)/);
  if (!match) return result;

  const sections = match[1].split(/(?=### Claim \d)/);
  for (const section of sections) {
    const header = section.match(/### Claim (\d+\w?)\b/i);
    if (!header) continue;

    const bullets = section.split("\n").filter(l => l.trim().startsWith("- "));
    const metrics = bullets.map(line => {
      const text = line.trim().replace(/^- /, "");
      const parts = text.match(/\*\*(.+?)\*\*:?\s*(.*)/);
      return {
        name: (parts?.[1] || text).replace(/[:\u200b]/g, "").trim(),
        description: (parts?.[2] || "").trim(),
      };
    });
    result.set(header[1].toLowerCase(), metrics);
  }
  return result;
}

// ─── Claims ───
function extractClaims() {
  const foundMatch = raw.match(
    /## Foundational claims\n([\s\S]*?)(?=\n<!-- pagebreak -->|\n## Relationship to Arbuckle)/
  );
  if (!foundMatch) return [];

  // Dashboard table
  const tableMatch = raw.match(/## Claims Dashboard\n\n\|[^\n]+\n\|[^\n]+\n((?:\|[^\n]+\n?)+)/);
  const dashRows = tableMatch
    ? tableMatch[1].trim().split("\n").map(row => {
        const cells = row.split("|").filter(Boolean).map(c => c.trim());
        return { number: cells[0], claim: cells[1], status: cells[2]?.replace(/\*\*/g, "").trim(), lastChanged: cells[3], keySignal: cells[4] };
      })
    : [];

  const sections = foundMatch[1].split(/(?=### Claim \d)/);
  const claims: any[] = [];

  for (const section of sections) {
    if (!section.match(/^### Claim \d/)) continue;
    const titleMatch = section.match(/### (Claim \d+\w?)\s*[—–-]\s*(.+)/);
    if (!titleMatch) continue;

    const number = titleMatch[1];
    const claimNum = number.replace("Claim ", "").toLowerCase();
    const title = titleMatch[2].trim();
    const dashRow = dashRows.find(r => r.number?.trim() === number.replace("Claim ", ""));

    const getField = (label: string) => {
      const re = new RegExp(`\\*\\*${label}\\*\\*\\s*\\n(.+?)(?=\\n\\n|\\n\\*\\*)`, "s");
      return section.match(re)?.[1]?.trim() || "";
    };
    const getBullets = (label: string) => {
      const re = new RegExp(`\\*\\*${label}\\*\\*\\s*\\n((?:- .+\\n?)+)`);
      const m = section.match(re);
      return m ? m[1].split("\n").filter(l => l.trim().startsWith("- ")).map(l => l.trim().replace(/^- /, "")) : [];
    };

    const statusMatch = section.match(/\*\*Status\*\*:?\s*(.+)/);
    let status = statusMatch?.[1]?.replace(/\*\*/g, "").replace(/\(.*\)/, "").trim() || dashRow?.status || "Active";
    status = status.replace(/ \/ Under evaluation/, "").trim();

    const splitMatch = section.match(/>\s*\*Split from[^*]+\*/);

    claims.push({
      id: `claim-${claimNum}`,
      number,
      title,
      statement: getField("Statement"),
      rationale: getField("Rationale"),
      status,
      lastChanged: dashRow?.lastChanged || "",
      keySignal: dashRow?.keySignal || "",
      supportingSignals: getBullets("Supporting signals"),
      challenges: getBullets("Challenges \\/ counter[\\-\u2011]?signals?"),
      q1Observations: getBullets("Q1 2026 observations"),
      evaluationCriteria: getBullets("Evaluation criteria"),
      splitNote: splitMatch?.[0]?.replace(/^>\s*\*/, "").replace(/\*$/, "").trim() || undefined,
    });
  }

  return claims;
}

// ─── Other sections ───
function extractMetadata() {
  const g = (key: string) => {
    const m = raw.match(new RegExp(`${key}:\\s*"(.+?)"`));
    return m?.[1] || "";
  };
  return {
    title: g("document_title"),
    author: (() => { const m = raw.match(/name:\s*"(.+?)"/); return m?.[1] || ""; })(),
    organization: (() => { const m = raw.match(/organization:\s*"(.+?)"/); return m?.[1] || ""; })(),
    creationDate: g("initial_creation_date"),
    revisionDate: g("current_revision_date"),
    version: (() => { const m = raw.match(/version_after:\s*"(.+?)"/); return m?.[1] || "v0.1.0"; })(),
    reviewCadence: "Quarterly",
  };
}

function extractExecSummary() {
  const match = raw.match(/## Executive Summary\n\n([\s\S]*?)(?=\n---)/);
  if (!match) return { coreThesis: "", whyMatters: "", takeaway: "" };
  const g = (label: string) => {
    const m = match[1].match(new RegExp(`\\*\\*${label}:\\*\\*\\s*(.+)`));
    return m?.[1]?.replace(/\*/g, "") || "";
  };
  return {
    coreThesis: g("Core thesis"),
    whyMatters: g("Why this matters"),
    takeaway: g("What leaders should take away"),
  };
}

function extractScope() {
  const match = raw.match(/## Scope and non.*?goals\n\n([\s\S]*?)(?=\n---)/);
  if (!match) return { inScope: [], outOfScope: [] };
  const getBullets = (label: string) => {
    const re = new RegExp(`\\*\\*${label}\\*\\*\\n((?:- .+\\n?)+)`);
    const m = match[1].match(re);
    return m ? m[1].split("\n").filter(l => l.trim().startsWith("- ")).map(l => l.trim().replace(/^- /, "")) : [];
  };
  return { inScope: getBullets("In scope"), outOfScope: getBullets("Out of scope") };
}

function extractDefinitions() {
  const match = raw.match(/## Definitions \(working\)\n\n([\s\S]*?)(?=\n---)/);
  if (!match) return [];
  const defs: any[] = [];
  const re = /\*\*(.+?)\*\*\s*\n(.+?)(?=\n\n|\n\*\*|$)/gs;
  let m;
  while ((m = re.exec(match[1]))) {
    defs.push({ term: m[1].trim(), definition: m[2].trim() });
  }
  return defs;
}

// ─── Assemble ───
const evidenceMap = extractEvidence();
const skepticismMap = extractSkepticism();
const metricsMap = extractMetrics();
const claims = extractClaims();

for (const claim of claims) {
  const key = claim.id.replace("claim-", "");
  claim.evidence = evidenceMap.get(key) || [];
  claim.skepticism = skepticismMap.get(key) || undefined;
  claim.metrics = metricsMap.get(key) || [];
}

const jsonld = {
  "@context": "https://schema.org",
  "@type": "DigitalDocument",
  ...extractMetadata(),
  executiveSummary: extractExecSummary(),
  coreThesis: "Technology roles are shifting from discrete execution to ontological orchestration: the definition, constraint, and sequencing of meaning in systems where execution is increasingly abundant.",
  scope: extractScope(),
  definitions: extractDefinitions(),
  claims,
  closingPrinciple: "Infinite capability without constrained intent does not produce success. It produces noise at scale.",
};

// Stats
console.log("=== Extraction Stats ===");
console.log(`Claims: ${claims.length}`);
for (const c of claims) {
  const sup = c.evidence.filter((e: any) => e.type === "support").length;
  const ctr = c.evidence.filter((e: any) => e.type === "counter").length;
  const withUrl = c.evidence.filter((e: any) => e.url).length;
  const withSummary = c.evidence.filter((e: any) => e.summary).length;
  const hasSkeptic = c.skepticism?.objection ? "✓" : "✗";
  console.log(`  ${c.number}: ${c.status} | ${sup}S/${ctr}C (${withUrl} urls, ${withSummary} summaries) | skeptic:${hasSkeptic} | ${c.metrics.length} metrics`);
}
console.log(`Definitions: ${jsonld.definitions.length}`);

const jsonStr = JSON.stringify(jsonld, null, 2);
fs.writeFileSync("doctrine.jsonld", jsonStr);
console.log(`\nWrote doctrine.jsonld (${jsonStr.length} chars)`);
