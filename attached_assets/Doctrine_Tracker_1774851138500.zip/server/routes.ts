import type { Express } from "express";
import { createServer, type Server } from "http";
import path from "path";
import { parseDoctrine } from "./doctrine-parser";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  const doctrinePath = path.resolve(process.cwd(), "doctrine-normalized.md");

  // Cache parsed doctrine (re-parse on each request in dev for live updates)
  let cachedDoctrine: ReturnType<typeof parseDoctrine> | null = null;
  let lastParsed = 0;

  function getDoctrine() {
    const now = Date.now();
    // Re-parse every 5 seconds in dev to pick up file changes
    if (!cachedDoctrine || now - lastParsed > 5000) {
      try {
        cachedDoctrine = parseDoctrine(doctrinePath);
        lastParsed = now;
      } catch (err) {
        console.error("Failed to parse doctrine:", err);
        if (!cachedDoctrine) throw err;
      }
    }
    return cachedDoctrine;
  }

  // Level 1: Overview — all claims with status, key signal
  app.get("/api/doctrine", (_req, res) => {
    try {
      const doctrine = getDoctrine();
      res.json(doctrine);
    } catch (err) {
      res.status(500).json({ error: "Failed to parse doctrine file" });
    }
  });

  // Level 2: Single claim detail
  app.get("/api/claims/:id", (req, res) => {
    try {
      const doctrine = getDoctrine();
      const claim = doctrine.claims.find((c) => c.id === req.params.id);
      if (!claim) {
        return res.status(404).json({ error: "Claim not found" });
      }
      res.json(claim);
    } catch (err) {
      res.status(500).json({ error: "Failed to parse doctrine file" });
    }
  });

  return httpServer;
}
