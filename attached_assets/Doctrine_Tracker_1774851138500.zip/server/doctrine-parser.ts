import fs from "fs";
import type { Doctrine } from "../shared/schema";

/**
 * Parses the doctrine markdown file by extracting the embedded JSON-LD block.
 * 
 * The markdown file contains a <script type="application/ld+json"> block
 * with the full structured data. This is the single source of truth for
 * the UI — no regex parsing of markdown needed.
 */
export function parseDoctrine(filePath: string): Doctrine {
  const raw = fs.readFileSync(filePath, "utf-8");

  // Extract the JSON-LD block
  const jsonldMatch = raw.match(
    /<script type="application\/ld\+json">\s*([\s\S]*?)\s*<\/script>/
  );

  if (!jsonldMatch) {
    throw new Error(
      "No JSON-LD block found in doctrine file. " +
      "Expected <script type=\"application/ld+json\">...</script>"
    );
  }

  const data = JSON.parse(jsonldMatch[1]);

  // Map JSON-LD structure to our Doctrine type
  return {
    metadata: {
      title: data.title || "Doctrine",
      author: data.author || "",
      organization: data.organization || "",
      creationDate: data.creationDate || "",
      revisionDate: data.revisionDate || "",
      version: data.version || "v0.1.0",
      reviewCadence: data.reviewCadence || "Quarterly",
    },
    coreThesis: data.coreThesis || "",
    executiveSummary: {
      coreThesis: data.executiveSummary?.coreThesis || "",
      whyMatters: data.executiveSummary?.whyMatters || "",
      takeaway: data.executiveSummary?.takeaway || "",
    },
    claims: (data.claims || []).map((c: any) => ({
      id: c.id || "",
      number: c.number || "",
      title: c.title || "",
      shortTitle: c.title?.split(/[—–:,]/)[0]?.trim() || c.title || "",
      statement: c.statement || "",
      rationale: c.rationale || "",
      status: c.status || "Active",
      lastChanged: c.lastChanged || "",
      keySignal: c.keySignal || "",
      supportingSignals: c.supportingSignals || [],
      challenges: c.challenges || [],
      q1Observations: c.q1Observations || [],
      evaluationCriteria: c.evaluationCriteria || [],
      evidence: (c.evidence || []).map((e: any) => ({
        title: e.title || "",
        author: e.author || undefined,
        url: e.url || undefined,
        tier: e.tier || undefined,
        summary: e.summary || undefined,
        type: e.type || "support",
      })),
      skepticism: c.skepticism
        ? {
            objection: c.skepticism.objection || "",
            falsificationCriteria: c.skepticism.falsification || [],
          }
        : undefined,
      metrics: (c.metrics || []).map((m: any) => ({
        name: m.name || "",
        description: m.description || "",
      })),
      splitNote: c.splitNote || undefined,
    })),
    definitions: (data.definitions || []).map((d: any) => ({
      term: d.term || "",
      definition: d.definition || "",
    })),
    scope: {
      inScope: data.scope?.inScope || [],
      outOfScope: data.scope?.outOfScope || [],
    },
    closingPrinciple: data.closingPrinciple || "",
  };
}
